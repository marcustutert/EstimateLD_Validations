#include <Rcpp.h>
using namespace Rcpp;
// [[Rcpp::export]]
NumericMatrix allele_frequency_update_c(NumericVector Gamma_Weights_States,
                                        IntegerMatrix ref_allele_matrix,
                                        NumericMatrix weight_matrix,
                                        int row_update) {
  int nsnps = ref_allele_matrix.ncol();
  int zero_based_row_update = row_update - 1; //Convert from R to Rcpp indexed
  NumericMatrix allele_frequencies(Gamma_Weights_States.length(), nsnps); //Initialize the matrix
  double w = 0;
  for (int i = 0; i < nsnps; i++) { //Loop through the columns
    for(int i_col = 0; i_col < Gamma_Weights_States.length(); i_col++) {
      double val = 0;
      double denom = 0;
      for(int i_row = 0; i_row < weight_matrix.nrow(); i_row++) {
        if (i_row == zero_based_row_update) {
          w = Gamma_Weights_States(i_col);
        } else {
          w = weight_matrix(i_row, i);
        }
        val += w * ref_allele_matrix(i_row, i);
        denom += w;
      }
      allele_frequencies(i_col, i) =  val / denom;
    }
  }
  return(transpose(allele_frequencies));
}
// [[Rcpp::export]]
NumericMatrix forward_pass_c(NumericMatrix allele_frequency_matrix,
                             double        diag_transition) {
  //Get Matrix Constants
  double nsnps   = allele_frequency_matrix.ncol();
  double nstates = allele_frequency_matrix.nrow();

  double     c = (1-diag_transition)/(nstates-1);
  double     a = diag_transition - c;

  NumericMatrix forward_pass_matrix(nstates, nsnps); //Initialize the matrix
  NumericVector pi_initial      = rep(1/nstates,nstates); //Get initial probabilities (pi's; uniform)

  //Replace first column in forward pass matrix
  forward_pass_matrix( _ , 0)    = pi_initial;
  for (int k = 0; k < nstates; k++){ //Loop through initial state probabilities
    forward_pass_matrix(k,0) = pi_initial(k) * allele_frequency_matrix(k,0);
  }
  //Normalize the first column of probabilities
  forward_pass_matrix(_,0) = forward_pass_matrix(_,0)/sum(forward_pass_matrix(_,0));

  NumericVector fp0 = forward_pass_matrix(_,0); //Store first column
  for (int t = 0; t < (nsnps-1); t++) { //Loop through the columns (SNPS)
    //Sum the mixed states as well as the averaging factor
    NumericVector fp1 = c + (fp0*a);
    //Now multiply by the observed probability at the length in the sequence
    fp1 = ( c+ (fp0*a)) * allele_frequency_matrix(_,t+1);
    //Normalize and scale the probabilities
    fp0 = fp1/sum(fp1);
    //Store the results
    forward_pass_matrix(_,t+1) = fp0;
  }
  return(forward_pass_matrix);
}

