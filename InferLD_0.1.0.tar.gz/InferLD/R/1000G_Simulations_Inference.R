thousand_genome_data_sim = function(chr,                     #Chromsone (1-22)
                                    start_bp,                #SNP starting position (bp)
                                    end_bp,                  #SNP ending position (bp))
                                    ref_super_pop,
                                    ref_intra_pop   = FALSE, #Assume that the reference panel only is a SUPER Pop (EUR/AFR/SEA...)
                                    gwas_super_pop  = FALSE, #Assume that the GWAS panel only is a INTRA Pop (CEU/JPT/MXL...)
                                    gwas_intra_pop,
                                    associations    = FALSE,  #Create the GWAS SS under the null
                                    CV_Index,                 #Index of the possible CV's in the region,
                                    ref_pop_size,             #Size of reference population
                                    gwas_pop_size,
                                    remove_target,
                                    directory,
                                    genetic_map     = TRUE)            #Size of GWAS population

{
  dir.create(sprintf("/well/mcvean/mtutert/1000_Genomes/inference_files/%s",directory))
  #Performing subletting of the 1000G files (on the cluster)
  options(scipen=999)


  samples           = read.table("/well/mcvean/mtutert/1000_Genomes/1000GP_Phase3.samples",
                                 header = FALSE)                                          #Read in 1000G file

  if (remove_target== TRUE) { #Remove the GWAS population from the reference panel
      ref_pop_sample_id = samples[c(samples$V3 == ref_super_pop),1]
      gwas_remove_id    = samples[c(samples$V2 == gwas_intra_pop),1]
      ref_pop_sample_id = setdiff(ref_pop_sample_id, gwas_remove_id)
      #Subset to individuals in SUPER POP
  }
  else{ #Include the GWAS population from the SS in the ref population
      ref_pop_sample_id = samples[samples$V3 == ref_super_pop,1]                              #Subset to individuals in SUPER POP
  }
  write.table(x         = ref_pop_sample_id,
              file      = "/well/mcvean/mtutert/1000_Genomes/ref_panel_indivs",
              quote     = FALSE,
              row.names = FALSE,
              col.names = FALSE) #Upload file to the cluster for BCFTOOLS to read

  gwas_pop_sample_id = samples[samples$V2 == gwas_intra_pop,1]                              #Subset to individuals in SUPER POP
  write.table(x         = gwas_pop_sample_id,
              file      = "/well/mcvean/mtutert/1000_Genomes/gwas_panel_indivs",
              quote     = FALSE,
              row.names = FALSE,
              col.names = FALSE) #Upload file to the cluster for BCFTOOLS to read

  #Perform the actual subsetting commands
  #We will need to paste this command all together
  ref_subset_command = sprintf(
    "/apps/well/bcftools/1.4.1/bin/bcftools view -Oz -S /well/mcvean/mtutert/1000_Genomes/ref_panel_indivs -r 1:%s-%s  /well/mcvean/mtutert/1000_Genomes/VCF/ALL.chr%s.phase3_shapeit2_mvncall_integrated_v5.20130502.genotypes.vcf.gz >                        /well/mcvean/mtutert/1000_Genomes/filtered_files/ref_panel.vcf.gz", start_bp, end_bp, chr)

  ref_convert_command = "/apps/well/bcftools/1.4.1/bin/bcftools convert -h /well/mcvean/mtutert/1000_Genomes/filtered_files/ref_panel /well/mcvean/mtutert/1000_Genomes/filtered_files/ref_panel.vcf.gz"

  #Perform the actual subsetting command
  gwas_subset_command = sprintf(
    "/apps/well/bcftools/1.4.1/bin/bcftools view -Oz -S /well/mcvean/mtutert/1000_Genomes/gwas_panel_indivs -r 1:%s-%s   /well/mcvean/mtutert/1000_Genomes/VCF/ALL.chr%s.phase3_shapeit2_mvncall_integrated_v5.20130502.genotypes.vcf.gz >                            /well/mcvean/mtutert/1000_Genomes/filtered_files/gwas_panel.vcf.gz", start_bp, end_bp, chr)

  #Then we wish to convert them to the IMPUTE2 format (hap/legend/samples)
  gwas_convert_command = "/apps/well/bcftools/1.4.1/bin/bcftools convert -h /well/mcvean/mtutert/1000_Genomes/filtered_files/gwas_panel /well/mcvean/mtutert/1000_Genomes/filtered_files/gwas_panel.vcf.gz"

  commands = paste(ref_subset_command,gwas_subset_command,ref_convert_command,gwas_convert_command,sep = ";")
  system(commands,intern = FALSE,wait = TRUE)

  ################################### Filtering Variants #####################

  #Now we want to take the hapltoype files in both ref & gwas, and remove anything below 1% MAF (and anything non-segregating in either pop)
  gwas_panel = t(read.table("/well/mcvean/mtutert/1000_Genomes/filtered_files/gwas_panel.hap.gz"))#Read in GWAS Panel
  ref_panel  = t(read.table("/well/mcvean/mtutert/1000_Genomes/filtered_files/ref_panel.hap.gz"))  #Read in Ref Panel

  remove_index_low_freq_ref = which(colSums(ref_panel)/nrow(ref_panel)*100 <= 1)
  #Remove all SNPs that have been fixed (usually due to high Fst)
  remove_index_fixed_ref = which(colSums(ref_panel) == nrow(ref_panel))
  #Merge these indexes together
  remove_index_ref = c(remove_index_low_freq_ref, remove_index_fixed_ref)

  #We also need to remove all the variants that are at 0% or 100% in the GWAS dataset as well
  remove_index_low_freq_gwas = which(colSums(gwas_panel)/nrow(gwas_panel)*100 <= 1)
  #Remove all SNPs that have been fixed (usually due to high Fst)
  remove_index_fixed_gwas = which(colSums(gwas_panel) == nrow(gwas_panel))
  #Merge these indexes together...
  remove_index_gwas = c(remove_index_low_freq_gwas,remove_index_fixed_gwas)

  ##Now merge both the gwas and reference panel variants together (and remove duplicates)
  filtered_variants_index = unique(c(remove_index_gwas,remove_index_ref))

  #Now we want to add the BP's of the positions that were NOT filtered
  snps       = seq(1:ncol(gwas_panel))
  snps_kept  = setdiff(snps,filtered_variants_index)

  #Now find the BPs of these SNPs by going into the legends file
  snp_legend  = read.table("/well/mcvean/mtutert/1000_Genomes/filtered_files/gwas_panel.legend.gz", header = TRUE)
  snp_bp_kept = snp_legend$position[snps_kept]

  if (length(filtered_variants_index)>0) {
    ref_panel  = ref_panel[,-filtered_variants_index]
    gwas_panel = gwas_panel[,-filtered_variants_index]
  }



  #######We will have to break the code if we remove all the variants!####
  if (ncol(gwas_panel) == 0) {
    break
  }
  colnames(gwas_panel) <- snp_bp_kept
  colnames(ref_panel)  <- snp_bp_kept
  print(dim(ref_panel))
  print(length( colnames(ref_panel) ))
  write.table(x         = ref_panel,
              file      = sprintf("/well/mcvean/mtutert/1000_Genomes/inference_files/%s/ref_panel_filtered",directory),
              quote     = FALSE,
              row.names = FALSE,
              col.names = TRUE)

  write.table(x         = gwas_panel,
              file      = sprintf("/well/mcvean/mtutert/1000_Genomes/inference_files/%s/gwas_panel_filtered",directory),
              quote     = FALSE,
              row.names = FALSE,
              col.names = TRUE)

  if (genetic_map == TRUE) {
    #Load in genetic map
    genetic_map   = read.table(sprintf("/well/mcvean/mtutert/1000_Genomes/genetic_map_chr%s_combined_b37.txt",chr), header = TRUE)
    #Get the macroscopic hotspot version for the recomb hotspots
    scaled_recomb = genetic_map_hotspots(genetic         = genetic_map,
                                         start_position  = snp_bp_kept[1] ,
                                         end_position    = snp_bp_kept[length(snp_bp_kept)],
                                         nhaps_reference = ncol(ref_panel))
    #Now we need to get the averaged transition rate for the HMM
    transition_rate_HMM = transition_rates_genetic_map(transition_rates = scaled_recomb,
                                                       ref_panel        = ref_panel,
                                                       start_position   = start_bp,
                                                       end_position     = end_bp,
                                                       directory        = directory)
    print(transition_rate_HMM)
    return(transition_rate_HMM)
  }
}

#Write a function that uses the 1000G haps/legends/sample files we've previously extracted and run it with HAPGEN2
#In order to generate realistic case/control data

#Write a function that takes the data from 1000G VCF's (or any haplotype matrix) and throws on GWAS SS on top
gwas_sim = function(haplotypes,   #These are the GWAS Haplotypes from msprime (matrix)
                    ncausal_snps      = 1, #Number of causal SNPs (numberic),
                    causal_snps_index = c(1), #index of SNP(s) which are causal
                    odds_ratio        = c(1), #Odds ratios for causal SNPS (vector)
                    ncases,                                  #Ncases in GWAS, default will be 50/50 split
                    ncontrols,                               #Ncontrols in GWAS
                    null              = FALSE,
                    LD_Matrix,
                    gwas_name,
                    directory)    #Specify direcotry name
{
  #Load in packages
  library(simGWAS)

  #First define constants re: data at hand
  nsnps = ncol(haplotypes)
  nhaps = nrow(haplotypes)

  #Create LD from list of haplotypes
  #GWAS_LD = LD_Matrix(haplotypes = haplotypes)
  #Make positive definite
  GWAS_LD <- as.matrix(LD_Matrix)

  #We need to create the dataframe with SNP frequency (assume data has already been QC'd)
  snps             = colnames(haplotypes) <- paste0("snp",1:nsnps) #List of SNPs (change rsid later)
  freq             = as.data.frame(haplotypes+1) #Create column for frequency
  freq$Probability = 1/nrow(freq)   #Frequency of each haplotype (uniform for now)
  FP               = make_GenoProbList(snps=snps,W=c(paste0("snp",causal_snps_index)),freq=freq)
  #Now we will take the haplotypes from the GWAS and build the SS with the sim gwas package
  #First we want the estimated z statistics
  nrep = 1

  if (null == TRUE) { #Under the null model
    expected_z_score = simulated_z_null(snps = snps, freq = freq, nrep = nrep) #Only one replicate
  }
  else{               #Under causal model
    expected_z_score = expected_z_score(N0           = ncontrols, # number of controls
                                        N1           = ncases, # number of cases
                                        snps         = snps, # column names in freq of SNPs for which Z scores should be generated
                                        W            = paste0("snp",causal_snps_index), # causal variants, subset of snps
                                        gamma.W      = (odds_ratio), # odds ratios
                                        freq         = freq, # reference haplotypes
                                        GenoProbList = FP) # FP above
  }

  #Next we need to take the simulated z scores and use multivariate normal draw
  sim_z_scores <- simulated_z_score(N0           = ncontrols,
                                    N1           = ncases,
                                    snps         = snps,
                                    W            = paste0("snp",causal_snps_index),
                                    gamma.W      = (odds_ratio),
                                    freq         = freq,
                                    GenoProbList = FP,
                                    nrep         = nrep)

  #Now we need to calculate the variance of the beta (beta SE^2)
  sim_var_beta <- simulated_vbeta(N0           = ncontrols, # number of controls
                                  N1           = ncases, # number of cases
                                  snps         = snps, # column names in freq of SNPs for which Z scores should be generated
                                  W            = paste0("snp",causal_snps_index), # causal variants, subset of snps
                                  gamma.W      = (odds_ratio), # odds ratios
                                  freq         = freq, # reference haplotypes
                                  GenoProbList = FP,
                                  nrep         = nrep)
  if(nrep>1){
      sim_z_means   = colMeans(sim_z_scores)
      sim_var_means = colMeans(sim_var_beta)
  }
  else{
      sim_z_means   = sim_z_scores
      sim_var_means = sim_var_beta
  }
  #Then we just back out the beta's as we normally would
  sim_beta      =  sim_z_means* sqrt(sim_var_means)

  #Output the betas and SE betas as a table
  if (nrep<2) {
   gwas_ss       = cbind(t(sim_beta),t(sqrt(sim_var_means)))
  }

  else{
  gwas_ss       = cbind(sim_beta,sqrt(sim_var_means))
  }

  write.table(x         = gwas_ss,
              file      = sprintf("/well/mcvean/mtutert/1000_Genomes/inference_files/%s/%s",directory,gwas_name),
              quote     = FALSE,
              row.names = TRUE,
              col.names = FALSE)
  return(gwas_ss)
}

#Function that takes the GWAS SS, GWAS hapltotypes and some LD matrix to to prepare fine-mapping results
#Also runs the pipeline
FINEMAP_pipeline =   function(gwas_ss,
                              LD_Panel,
                              study_name,#String, will be prefix of all the files
                              gwas_haps,
                              ncausal_snps,
                              inference#Potentially unknown (won't be used for finemapping, rather for parameter defs
                              )
{
  library(EstimateLD)
  #Read in the data first into Renvr.
  gwas_ss   = read.table(sprintf("/well/mcvean/mtutert/1000_Genomes/inference_files/%s",gwas_ss),fill = TRUE)
  gwas_haps = read.table(sprintf("/well/mcvean/mtutert/1000_Genomes/inference_files/%s",gwas_haps),fill = TRUE)

  #Define constants
  nsnps = nrow(gwas_ss)
  if (inference == TRUE) {
    LD_Panel = readRDS("/well/mcvean/mtutert/1000_Genomes/inference_files/weights_no_recomb/LD/LD_average_20200818_145240_35b.RData")
  }
  else{
    LD_Panel = LD_Matrix(read.table(sprintf("/well/mcvean/mtutert/1000_Genomes/inference_files/%s",LD_Panel),fill = TRUE))
  }
  #First we need to create the files necessary to run the fine-mapping
  #We will store them locally in /Users/marcustutert/Desktop/Oxford_Dphil/EstimateLD/GWAS_Sims_Finemapping
  #There are three files we need a master file, and LD file & a Z file that all have seperate directories
  dir.create(sprintf("/well/mcvean/mtutert/1000_Genomes/finemap_results/finemap_v1.4_x86_64/%s",study_name))

  ############ Master File ###############

  #The master file is a semicolon-separated text file and contains no space
  master_file_col_names = paste("z","ld","snp","config","cred","log","n_samples",sep = ";")
  #Now each line will be a separate dataset (later on the line we can combine the files?)
  #We'll sprintf each seperate for convience then paste em al ltogether
  z_file        = sprintf("%s/%s.z",study_name,study_name)
  ld_file       = sprintf("%s/%s.ld",study_name,study_name)
  snp_file      = sprintf("%s/%s.snp",study_name,study_name)
  config_file   = sprintf("%s/%s.config",study_name,study_name)
  cred_set_file = sprintf("%s/%s.cred",study_name,study_name)
  log_file      = sprintf("%s/%s.log",study_name,study_name)
  nsample_study = nrow(gwas_haps) #This can be hard-coded I guess

  #Paste em together
  master_file_data_names = paste(z_file,ld_file,snp_file,config_file,cred_set_file,log_file,nsample_study,sep = ";")
  #Create dataframe from it
  master_file           = as.data.frame(master_file_data_names)
  colnames(master_file) = master_file_col_names

  #Write the table to directory
  write.table(x         = master_file,
              file      = sprintf("/well/mcvean/mtutert/1000_Genomes/finemap_results/finemap_v1.4_x86_64/%s/master", study_name),
              quote     = FALSE,
              row.names = FALSE,
              col.names = TRUE)
  ############ LD File ###############
  write.table(x = LD_Panel,
              sprintf("/well/mcvean/mtutert/1000_Genomes/finemap_results/finemap_v1.4_x86_64/%s/%s.ld",study_name,study_name),
              quote = FALSE,
              row.names = FALSE,
              col.names = FALSE)

  ########## Z File ##########
  #Get col names for the z file
  z_file_col_names = paste("rsid","chromosome","position","allele1","allele2","maf","beta","se",sep = " ")
  #Get the data for each row (assuming no genomic position, this is from msprime )
  rsid       = paste("snp",seq(1:nsnps), sep = "")
  chromosome = paste("chr1",seq(1:nsnps), sep = "")
  position   = seq(1:nsnps)
  allele1    = rep("A",nsnps)
  allele2    = rep("T",nsnps)
  maf        = ifelse(colMeans(gwas_haps)>0.5,1-colMeans(gwas_haps),colMeans(gwas_haps))
  beta       = gwas_ss[,2]
  se         = gwas_ss[,3]

  z_file_data_names = paste(rsid,chromosome,position,allele1,allele2,maf,beta,se,sep = " ")

  z_file           = as.data.frame(z_file_data_names)
  colnames(z_file) = z_file_col_names
  #Write the table to directory
  write.table(x = z_file,
              file = sprintf("/well/mcvean/mtutert/1000_Genomes/finemap_results/finemap_v1.4_x86_64/%s/%s.z", study_name,study_name),
              quote = FALSE,
              row.names = FALSE,
              col.names = TRUE)

  #### Run FINEMAP ####
  setwd("/well/mcvean/mtutert/1000_Genomes/finemap_results/finemap_v1.4_x86_64")
  #Run it from command line
  system(sprintf("/well/mcvean/mtutert/1000_Genomes/finemap_results/finemap_v1.4_x86_64/finemap_v1.4_x86_64 --sss --in-files /well/mcvean/mtutert/1000_Genomes/finemap_results/finemap_v1.4_x86_64/%s/master  --dataset 1 --n-causal-snps %s --n-configs-top 100000", study_name,ncausal_snps))
}


#Analyze fine-mapping results using the .snp & .config files etc.
#This function will take in the config files and output the size of the credible set
cred_set_config = function(study_name){
  library(data.table)
  #Read in config table from FINEMAP output
  config             = read.table(sprintf("/well/mcvean/mtutert/1000_Genomes/finemap_results/finemap_v1.4_x86_64/%s/%s.config",study_name,study_name),header = TRUE)
  #Calculate config cumsum for the credible set (95%)
  cumsum_config_prob_index = min(which(cumsum(config$prob)>0.95))
  #Now we want to extract all SNPs from these files
  total_set_cred_snps      = paste(config$config[1:cumsum_config_prob_index], collapse = ",")
  #Split them into vectors
  cred_size_set            = sapply(strsplit(total_set_cred_snps,','), uniqueN)
  return(cred_size_set)
}

#Function will take in the config files and output how many SNPs in these resulting configuration do we need to tag all the variants
snps_needed_for_causal_variant = function(study_name,causal_variant){
  #Extract the config of SNPs as list
  config                     = read.table(sprintf("/well/mcvean/mtutert/1000_Genomes/finemap_results/finemap_v1.4_x86_64/%s/%s.config",study_name,study_name),header = TRUE,fill = TRUE)
  #Calculate config cumsum for the credible set (95%)
  total_set_config_snps      = paste(config$config[1:nrow(config)], collapse = ",")
  snps_stripped              = sapply(strsplit(total_set_config_snps,','), unique)
  #Now we want to ask how long many SNPs it takes to include all causal variants in cred set
  #Max will be the size of the interval (SNPs), min will be # of causal SNPs
  causal_variants_ID         =  paste0('snp', causal_variant)
  #Now we want to look at where there are matches to the causal variants to snp_stripped vector
   x = c()
  for (i in 1:length(causal_variants_ID)) {
    x[i] = match(causal_variants_ID[i],snps_stripped)
  }
  snps_needed = max(x)
  return(snps_needed)
}

#This function will look at how much posterior probability is assigned to the causal SNPs
causal_snps_bf = function(study_name,causal_variant){
  causal_variants_ID         =  paste0('snp', causal_variant)
  snp_results                = read.table(sprintf("/well/mcvean/mtutert/1000_Genomes/finemap_results/finemap_v1.4_x86_64/%s/%s.snp",study_name,study_name),header = TRUE,fill = TRUE)
  bf = c()
  for (i in 1:length(causal_variants_ID)) {
    #bf[i] =
  }
}
#Function that will take the GWAS SS and then perform the GWAS Imputation given some masked SNPs
impute<-function(reference_haplotypes,
                 sites.typed,
                 betas,
                 sd.betas,
                 min.AF=0.01,     #1% MAF
                 shrink.fac=1e-3, #For LD Shrinkage
                 LD)             #LD Panel #Ask if we should generate a new gwas_ss table
{
  #Parameters (number of snps)
  l<-ncol(reference_haplotypes);
  #First construct LD matrix (correlation snp-snp)
  rij<-LD;

  #Use a small amount of shrinkage to make it invertible / correct for LD overestimation
  ii<-1:l;
  im<-array(ii,c(l,l));
  del<-exp(-abs(im - t(im))*shrink.fac);

  #Get normalisation for Sigma
  fi<-apply(reference_haplotypes, 2, mean);
  gt.var<-sqrt(2*fi*(1-fi));
  vv<- gt.var %*% t(gt.var);
  R<-rij*del/vv;

  # #Figure out which sites are typed and untyped
  set.typed = sites.typed
  set.untyped<-setdiff(1:ncol(reference_haplotypes), sites.typed);

  #Solve correlation matrix
  inv.sig.typed = pseudoinverse(R[set.typed,set.typed], tol = 1e-1)
  W             = R[set.untyped,set.typed]
  expected_z    = W %*% inv.sig.typed %*% (betas/sd.betas)
  return(expected_z)
}

#This function will take a list of LD panels: Reference/GWAS/Inferred (high and low recomb)
#As well as the GWAS SS themselves
#It will output the r2's across replicate (for that region) as well as the index of the imputed variants
impute_accuracy_comparison = function(gwas_haplotypes,
                                      reference_haplotypes,
                                      inferred_LD           = FALSE,
                                      inferred_LD_no_recomb = FALSE,
                                      gwas_ss,
                                      nreplicate            = 100,
                                      typed_fraction        = 0.5){
  nsnps = ncol(gwas_haplotypes)
  r2 = matrix(data = NA,nrow = nreplicate,ncol = 4)
  for (i in 1:nreplicate) {
    browser()
    #Perform the SS by masking half of the SNPs randomly
    typed_fraction          = typed_fraction
    typed_sites             = sample(x = 1:nsnps, size = nsnps*typed_fraction) #Figure out which SNPs are typed
    expected_z_imputed_gwas = impute(reference_haplotypes = reference_haplotypes,
                                     sites.typed          = typed_sites,
                                     betas                = gwas_ss[typed_sites,2],
                                     sd.betas             = gwas_ss[typed_sites,3],
                                     LD                   = LD_Matrix(gwas_haplotypes))
  r2[i,1] = summary(lm((gwas_ss[-typed_sites,2]/gwas_ss[-typed_sites,3]~expected_z_imputed_gwas)))$r.squared

  expected_z_imputed_ref = impute(reference_haplotypes   = reference_haplotypes,
                                   sites.typed            = typed_sites,
                                   betas                  = gwas_ss[typed_sites,2],
                                   sd.betas               = gwas_ss[typed_sites,3],
                                   LD                     = LD_Matrix(reference_haplotypes))
  r2[i,2] = summary(lm((gwas_ss[-typed_sites,2]/gwas_ss[-typed_sites,3]~expected_z_imputed_ref)))$r.squared
  if (inferred_LD != FALSE) {
    expected_z_imputed_inferrred = impute(reference_haplotypes   = reference_haplotypes,
                                    sites.typed                  = typed_sites,
                                    betas                        = gwas_ss[typed_sites,2],
                                    sd.betas                     = gwas_ss[typed_sites,3],
                                    LD                           = inferred_LD )
    r2[i,3] = summary(lm((gwas_ss[-typed_sites,2]/gwas_ss[-typed_sites,3]~expected_z_imputed_inferrred)))$r.squared
  }
  if (inferred_LD_no_recomb != FALSE) {
    expected_z_imputed_inferrred_no_recomb = impute(reference_haplotypes   = reference_haplotypes,
                                                    sites.typed                      = typed_sites,
                                                    betas                            = gwas_ss[typed_sites,2],
                                                    sd.betas                         = gwas_ss[typed_sites,3],
                                                    LD                               = inferred_LD_no_recomb)
    r2[i,4] = summary(lm((gwas_ss[-typed_sites,2]/gwas_ss[-typed_sites,3]~expected_z_imputed_inferrred_no_recomb)))$r.squared
  }

  }
  return(r2)
}

