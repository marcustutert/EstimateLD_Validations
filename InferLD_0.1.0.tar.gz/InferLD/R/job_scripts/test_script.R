#Test an example job script to make sure pipelines are runnin
test_script = function(){
  print(seq(1,1e7))
}
recomb_test_submit = bash.execute.Rfunction(Rfunction = test_script,
                                            onPool = TRUE,
                                            dirExternal = "/well/mcvean/mtutert/",
                                            jobName = "test_pipeline",
                                            hold_jobID = "NA")
