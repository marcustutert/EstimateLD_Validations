dataTable = data.table(
  x = c( "a", "a", "b", "b", "c", "d", "d", "a" ),
  y = c( "a", "a", "a", "a", "b", "b", "b", "b" ),
  z = c(  4,    2,   1,   3,   3,   2,   1,   4 )
)

###################################################################
# Description: test containsColumns
###################################################################
test_that( "Test containsColumns", expect_equal( utils.data.table.containsColumns( dataTable, "x" ), TRUE ) )
test_that( "Test containsColumns", expect_equal( utils.data.table.containsColumns( dataTable, "y" ), TRUE ) )
test_that( "Test containsColumns", expect_equal( utils.data.table.containsColumns( dataTable, "w" ), FALSE ) )
test_that( "Test containsColumns", expect_equal( utils.data.table.containsColumns( dataTable, c() ), TRUE ) )
test_that( "Test containsColumns", expect_equal( utils.data.table.containsColumns( dataTable, c( "x", "y" ) ), TRUE ) )
test_that( "Test containsColumns", expect_equal( utils.data.table.containsColumns( dataTable, c( "x", "w" ) ), FALSE ) )

###################################################################
# Description: test indexRepeatedKeys
###################################################################
expected = data.table(
  x  = c( "a", "a", "a", "b", "b", "c", "d", "d" ),
  y  = c( "a", "a", "b", "a", "a", "b", "b", "b" ),
  I  = c(   1,   2,   3,   1,   2,   1,   1,  2  )
)
testDataTable = dataTable[ ,.( x, y ) ]
utils.data.table.indexRepeatedKeys( testDataTable, "x", indexColName = "I" )
setkey( testDataTable, NULL )
test_that( "Test indexRepeatedKeys", expect_equal( testDataTable, expected) )

expected = data.table(
  x  = c( "a", "a", "b", "b", "c", "d", "d", "a" ),
  y  = c( "a", "a", "a", "a", "b", "b", "b", "b" ),
  I  = c(   1,   2,   3,   4,   1,   2,   3,  4  )
)
testDataTable = dataTable[ ,.( x, y ) ]
utils.data.table.indexRepeatedKeys( testDataTable, "y", indexColName = "I" )
setkey( testDataTable, NULL )
test_that( "Test indexRepeatedKeys", expect_equal( testDataTable, expected) )

expected = data.table(
  x  = c( "a", "a", "a", "b", "b", "c", "d", "d" ),
  y  = c( "a", "a", "b", "a", "a", "b", "b", "b" ),
  I  = c(   1,   2,   1,   1,   2,   1,   1,  2  )
)
testDataTable = dataTable[ ,.( x, y ) ]
utils.data.table.indexRepeatedKeys( testDataTable, c( "x", "y" ), indexColName = "I" )
setkey( testDataTable, NULL )
test_that( "Test indexRepeatedKeys", expect_equal( testDataTable, expected) )

expected = data.table(
  x  = c( "b", "a", "b", "a", "d", "d", "c", "a" ),
  y  = c( "a", "a", "a", "a", "b", "b", "b", "b" ),
  z =  c(   1,   2,   3,   4,   1,   2,   3,  4  ),
  I  = c(   1,   2,   3,   4,   1,   2,   3,  4  )
)
testDataTable = copy( dataTable)
utils.data.table.indexRepeatedKeys( testDataTable, "y", indexColName = "I", orderColName = "z" )
setkey( testDataTable, NULL )
test_that( "Test indexRepeatedKeys", expect_equal( testDataTable, expected) )

expected = data.table(
  x  = c( "a", "b", "a", "b", "a", "c", "d", "d" ),
  y  = c( "a", "a", "a", "a", "b", "b", "b", "b" ),
  z =  c(   4,   3,   2,   1,   4,   3,   2,  1  ),
  I  = c(   1,   2,   3,   4,   1,   2,   3,  4  )
)
testDataTable = copy( dataTable)
utils.data.table.indexRepeatedKeys( testDataTable, "y", indexColName = "I", orderColName = "z", orderIncreasing = FALSE )
setkey( testDataTable, NULL )
test_that( "Test indexRepeatedKeys", expect_equal( testDataTable, expected) )

###################################################################
# Description: test replaceNA
###################################################################
dataTable = data.table( x = c( 1, 2, NA ), y = c( 3, 2, NA ) )
expected  = data.table( x = c( 1, 2, 0 ), y = c( 3, 2, 0 ) )
utils.data.table.replaceNA( dataTable )
test_that( "Test replaceNA", expect_equal( dataTable, expected ) )

dataTable = data.table( x = c( 1, 2, NA ), y = c( 3, 2, NA ) )
expected  = data.table( x = c( 1, 2, NA ), y = c( 3, 2, 0 ) )
utils.data.table.replaceNA( dataTable, columns = "y" )
test_that( "Test replaceNA", expect_equal( dataTable, expected ) )

dataTable = data.table( x = c( 1, 2, NA ), y = c( 3, 2, NA ) )
expected  = data.table( x = c( 1, 2, 1.5 ), y = c( 3, 2, 1.5 ) )
utils.data.table.replaceNA( dataTable, value = 1.5 )
test_that( "Test replaceNA", expect_equal( dataTable, expected ) )

###################################################################
# Description: test rowMaxs
###################################################################
dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ) )
expected  = c( 3, 2 ,4)
test_that( "Test rowMaxs", expect_equal( utils.data.table.rowMaxs( dataTable ), expected ) )

dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ), z = c( 1,4,2 ) )
expected  = c( 1, 2, 3)
test_that( "Test rowMaxs", expect_equal( utils.data.table.rowMaxs( dataTable, columns = "x" ), expected ) )

dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ), z = c( 1,4,2 ) )
expected  = c( 2, 2, 3)
test_that( "Test rowMaxs", expect_equal( utils.data.table.rowMaxs( dataTable, columns = "x", constant = 2 ), expected ) )

###################################################################
# Description: test rowMaxCols
###################################################################
dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ) )
expected  = c( "y", "x", "y" )
test_that( "Test rowMaxCols", expect_equal( utils.data.table.rowMaxCols( dataTable ), expected ) )

dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ), z = c( 1,4,2 ) )
expected  = c( "x", "z", "x" )
test_that( "Test rowMaxCols", expect_equal( utils.data.table.rowMaxCols( dataTable, columns = c( "x", "z" ) ), expected ) )

###################################################################
# Description: test rowMinCols
###################################################################
dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ) )
expected  = c( "x", "y", "x" )
test_that( "Test rowMinCols", expect_equal( utils.data.table.rowMinCols( dataTable ), expected ) )

dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ), z = c( 1,4,2 ) )
expected  = c( "x", "x", "z" )
test_that( "Test rowMinCols", expect_equal( utils.data.table.rowMinCols( dataTable, columns = c( "x", "z" ) ), expected ) )

###################################################################
# Description: test rowMins
###################################################################
dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ) )
expected  = c( 1, 1 ,3 )
test_that( "Test rowMins", expect_equal( utils.data.table.rowMins( dataTable ), expected ) )

dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ), z = c( 1,4,2 ) )
expected  = c( 1, 2, 3 )
test_that( "Test rowMins", expect_equal( utils.data.table.rowMins( dataTable, columns = "x" ), expected ) )

dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ), z = c( 1,4,2 ) )
expected  = c( 1, 2, 2 )
test_that( "Test rowMins", expect_equal( utils.data.table.rowMins( dataTable, columns = "x", constant = 2 ), expected ) )

###################################################################
# Description: test rowMeans
###################################################################
dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ) )
expected  = c( 2, 1.5 ,3.5 )
test_that( "Test rowMeans", expect_equal( utils.data.table.rowMeans( dataTable ), expected ) )

dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ), z = c( 1,4,2 ) )
expected  = c( 1, 2, 3 )
test_that( "Test rowMeans", expect_equal( utils.data.table.rowMeans( dataTable, columns = "x" ), expected ) )

###################################################################
# Description: test rowSums
###################################################################
dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ) )
expected  = c( 4, 3, 7 )
test_that( "Test rowSums", expect_equal( utils.data.table.rowSums( dataTable ), expected ) )

dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ), z = c( 1,4,2 ) )
expected  = c( 1, 2, 3 )
test_that( "Test rowSums", expect_equal( utils.data.table.rowSums( dataTable, columns = "x" ), expected ) )

###################################################################
# Description: test rowMedians
###################################################################
dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ), z = c( 2,4,2 ) )
expected  = c( 2, 2, 3 )
test_that( "Test rowMedians", expect_equal( utils.data.table.rowMedians( dataTable ), expected ) )

###################################################################
# Description: test rowQuantiels
###################################################################
data = matrix( c( sample( 0:100, 101 ), sample( 100:200, 101 ), sample( 200:300, 101 ) ), nrow = 3, ncol = 101, byrow = TRUE )
dataTable = data.table( data)
expected  = c( 25, 125, 225 )
test_that( "Test rowQuantiles", expect_equal( utils.data.table.rowQuantiles( dataTable, probs = 0.25 ), expected ) )
expected  = c( 95, 195, 295 )
test_that( "Test rowQuantiles", expect_equal( utils.data.table.rowQuantiles( dataTable, probs = 0.95 ), expected ) )
test_that( "Test rowQuantiles", expect_equal( utils.data.table.rowQuantiles( dataTable, probs = 0.5 ), utils.data.table.rowMedians( dataTable ) ) )

###################################################################
# Description: test search
###################################################################
dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ), z = c( 1, 4, 5 ) )
expected = dataTable[ 3 ]
test_that( "Test search", expect_equal( utils.data.table.search( dataTable, 5 ), expected ) )
expected = dataTable[ 1:2 ]
test_that( "Test search", expect_equal( utils.data.table.search( dataTable, 1 ), expected ) )
expected = dataTable[ c( 1, 3 ) ]
test_that( "Test search", expect_equal( utils.data.table.search( dataTable, 3 ), expected ) )
expected = dataTable[ 3 ]
test_that( "Test search", expect_equal( utils.data.table.search( dataTable, 3, columns = c( "x", "z" ) ), expected ) )

###################################################################
# Description: test project
###################################################################
dataTable = data.table( x = c( 1, 2, 3 ), y = c( 3, 1, 4 ), z = c( 1, 4, 5 ) )
expected = dataTable[ , .( x, y ) ]
test_that( "Test project", expect_equal( utils.data.table.project( dataTable, c( "x", "y" ) ), expected ) )
expected = dataTable[ , x ]
test_that( "Test project", expect_equal( utils.data.table.project( dataTable, "x", asVector = TRUE ), expected ) )
expected = dataTable[ , .( x, y ) ]
test_that( "Test project", expect_equal( utils.data.table.project( dataTable, c( "z"), allBut = TRUE ), expected ) )

###################################################################
# Description: test stats.correlationMatrix
###################################################################
dataTable = data.table( index = c( 1, 1, 2, 2 ), id = c( 1, 2, 1, 2 ) )
expected  = matrix( 1, ncol = 2, nrow = 2, dimnames = list( c( "1", "2"), c( "1", "2" ) ) )
test_that( "Test stats.correlationMatrix correlated", expect_equal( utils.data.table.stats.correlationMatrix( dataTable, indexCol = "index", identifierCol = "id" ), expected ) )
dataTable = data.table( index = c( 1, 2 ), id = c( 1, 2 ) )
expected  = matrix( c( 1, -1, -1, 1 ), ncol = 2, nrow = 2, dimnames = list( c( "1", "2"), c( "1", "2" ) ) )
test_that( "Test stats.correlationMatrix anti-correlated", expect_equal( utils.data.table.stats.correlationMatrix( dataTable, indexCol = "index", identifierCol = "id" ), expected ) )
dataTable = data.table( index = c( 1, 1, 2 ), id = c( 1, 1, 2 ) )
expected  = matrix( c( 1, -1, -1, 1 ), ncol = 2, nrow = 2, dimnames = list( c( "1", "2"), c( "1", "2" ) ) )
test_that( "Test stats.correlationMatrix repeated data", expect_equal( utils.data.table.stats.correlationMatrix( dataTable, indexCol = "index", identifierCol = "id" ), expected ) )
dataTable = data.table( index = c( 1, 2, 2, 3 ), id = c( 1, 1, 2, 2 ) )
expected  = matrix( c( 1, -0.5, 0.5, 1 ), ncol = 2, nrow = 2, dimnames = list( c( "1", "2"), c( "1", "2" ) ) )
test_that( "Test stats.correlationMatrix partially correlated", expect_equal( utils.data.table.stats.correlationMatrix( dataTable, indexCol = "index", identifierCol = "id" ), expected ) )




