library( testthat )

###################################################################
# Description: test utils.integrate.logunimodal.vectorized
###################################################################
N = 1e3

###################################################################
# Description: test factorial integral
###################################################################
x1   = ceiling( runif( N, 10, 1e4 ) )
exp1 = lfactorial( x1 )
f = function( z ) return( -z + x1 * log( z  ))
max1 = x1 * runif( N, 0.8, 1.2 )
int = utils.integrate.logunimodal.vectorized( f, max1 )
test_that( "Log factorial built in function against vectorized integral", expect_lt( max( abs( int - exp1 ) ), 1e-5 ) )

###################################################################
# Description: test exponential integral
###################################################################
x2   = runif( N, 0.1, 10 )
exp2 = - log( x2 )
f = function( z ) return( - z * x2 )
max2 = rep( 1e-6, N )
int = utils.integrate.logunimodal.vectorized( f, max2 )
test_that( "Log exponential against vectorized integral", expect_lt( max( abs( int - exp2 ) ), 1e-5 ) )

###################################################################
# Description: tes mixed types
###################################################################
f  = function( z ) return( c( - z[ 1:N ] + x1 * log( z[ 1:N ] ), - z[ ( N + 1 ):( 2 * N ) ] * x2  ) )
int = utils.integrate.logunimodal.vectorized( f, c( max1, max2 ) )
test_that( "Log combined against vectorized integral", expect_lt( max( abs(  int - c( exp1, exp2 ) ) ), 1e-5 ) )



