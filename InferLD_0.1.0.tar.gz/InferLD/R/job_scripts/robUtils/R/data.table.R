###################################################################/
# Name:       utils.data.table.replaceNA
# Descrption: takes data.table and replaces NA values with a given value
# Args:       dataTable    - a data.table
#             columns      - a vector of column names or NULL is all columns
# Return:     TRUE/FALSE
###################################################################/
utils.data.table.replaceNA = function( dataTable, columns = NULL, value = 0 )
{
  if( !is.data.table( dataTable ) )
    stop( "dataTable must be a data.table")

  if( is.null( columns ) )
    columns = names( dataTable )

  for( i in columns )
    dataTable[ is.na( get( i ) ), (i) := value ]
}

###################################################################/
# Name:       utils.data.table.rowMaxs
# Descrption: takes data.table finds the max value in a row (or for a set of columns)
# Args:       dataTable    - a data.table
#             columns      - a vector of column names or NULL is all columns
# Return:     vector
###################################################################/
utils.data.table.rowMaxs = function( dataTable, columns = NULL, constant = NULL, rank = NULL )
{
  return( .data.table.rowOp( dataTable, columns = columns, op = "rowMaxs", constant = constant, args = list( rank = rank ) ) )
}

###################################################################/
# Name:       utils.data.table.rowMaxCols
# Descrption: takes data.table finds the column in which the max value in a row is (or for a set of columns)
# Args:       dataTable    - a data.table
#             columns      - a vector of column names or NULL is all columns
# Return:     vector
###################################################################/
utils.data.table.rowMaxCols = function( dataTable, columns = NULL, rank = NULL )
{
  return( .data.table.rowOp( dataTable, columns = columns, op = "rowMaxCols", args = list( rank = rank ) ) )
}

###################################################################/
# Name:       utils.data.table.rowMinCols
# Descrption: takes data.table finds the column in which the min value in a row is (or for a set of columns)
# Args:       dataTable    - a data.table
#             columns      - a vector of column names or NULL is all columns
# Return:     vector
###################################################################/
utils.data.table.rowMinCols = function( dataTable, columns = NULL )
{
  return( .data.table.rowOp( dataTable, columns = columns, op = "rowMinCols" ) )
}

###################################################################/
# Name:       utils.data.table.rowMedians
# Descrption: takes data.table finds the median value in a row (or for a set of columns)
# Args:       dataTable    - a data.table
#             columns      - a vector of column names or NULL is all columns
# Return:     vector
###################################################################/
utils.data.table.rowMedians = function( dataTable, columns = NULL )
{
  return( .data.table.rowOp( dataTable, columns = columns, op = "rowMedians" ) )
}

###################################################################/
# Name:       utils.data.table.rowMins
# Descrption: takes data.table finds the min value in a row (or for a set of columns)
# Args:       dataTable    - a data.table
#             columns      - a vector of column names or NULL is all columns
# Return:     vector
###################################################################/
utils.data.table.rowMins = function( dataTable, columns = NULL, constant = NULL )
{
  return( .data.table.rowOp( dataTable, columns = columns, constant = constant, op = "rowMins" ) )
}

###################################################################/
# Name:       utils.data.table.rowSums
# Descrption: takes data.table finds the sum value in a row (or for a set of columns)
# Args:       dataTable    - a data.table
#             columns      - a vector of column names or NULL is all columns
# Return:     vector
###################################################################/
utils.data.table.rowSums = function( dataTable, columns = NULL )
{
  return( .data.table.rowOp( dataTable, columns = columns, op = "rowSums" ) )
}

###################################################################/
# Name:       utils.data.table.rowMeans
# Descrption: takes data.table finds the mean value in a row (or for a set of columns)
# Args:       dataTable    - a data.table
#             columns      - a vector of column names or NULL is all columns
# Return:     vector
###################################################################/
utils.data.table.rowMeans = function( dataTable, columns = NULL )
{
  return( .data.table.rowOp( dataTable, columns = columns, op = "rowMeans" ) )
}

###################################################################/
# Name:       utils.data.table.rowQuantiles
# Descrption: takes data.table finds thequantiles in a row (or for a set of columns)
# Args:       dataTable    - a data.table
#             columns      - a vector of column names or NULL is all columns
# Return:     vector or matrix
###################################################################/
utils.data.table.rowQuantiles = function( dataTable, columns = NULL, probs = c( 0.25, 0.5, 0.75 ) )
{
  return( .data.table.rowOp( dataTable, columns = columns, op = "rowQuantiles", args = list( probs = probs ) ) )
}

###################################################################/
# Name:       .rowMaxs
###################################################################/
.rowMaxs = function( dataTable, columns, constant, rank, type = "value" )
{
  if( !is.null( constant ) )
    utils.throw( "cannot specify a constant when looking for a lower ranked value" )

  nCols = length( columns )
  nRows = dataTable[ ,.N ]

  # make sure that rank is in range, if not move to min/max as appropriate
  if( rank > nCols )
    rank = nCols
  if( rank < 1 )
    rank = 1

  t = utils.data.table.project( dataTable, columns )
  t[ , rowNumber := 1:nRows ]
  t = melt.data.table( t, "rowNumber", columns )[ order( rowNumber, -value, variable ) ]

  selectRows = seq( rank, nCols * nRows, by = nCols )

  if( type == "value" )
    return( t[ selectRows, value ] )
  else
    return( as.character( t[ selectRows, variable ] ) )
}

###################################################################/
# Name:       .data.table.rowOp
###################################################################/
.data.table.rowOp = function( dataTable, columns = NULL, op = "rowMaxs", constant = NULL, args = list() )
{
  if( !is.data.table( dataTable ) )
    utils.throw( "dataTable must be a data.table")

  if( is.null( columns ) )
  {
    columns = names( dataTable )
    types   = as.character( lapply( dataTable[ ,.SD, .SDcols = columns ], class ) )
    columns = columns[ which( types == "integer" | types == "numeric" ) ]
  }

  if( is.null( constant ) )
    args = append( list( as.matrix( dataTable[ ,.SD, .SDcols = columns ] ) ), args )
  else
    args = append( list( cbind( as.matrix( dataTable[ ,.SD, .SDcols = columns ] ), constant ) ), args )

  if( op == "rowMaxs" & !is.null( args[[ "rank" ]] ) )
    return( .rowMaxs( dataTable, columns, constant, args[[ "rank" ]] ) )
  if( op == "rowMinCols" )
    return( columns[ apply( args[[ 1 ]], 1, which.min ) ] )
  else
  if( op == "rowMaxCols" )
  {
    if( is.null( args[[ "rank" ]] ) )
      return( columns[ apply( args[[ 1 ]], 1, which.max ) ] )
    else
      return( .rowMaxs( dataTable, columns, constant, args[[ "rank" ]] , type = "colName" ) )
  }
  else
  return( do.call( op, args = args ) )
}

###################################################################/
# Name:       utils.data.table.containsColumns
# Descrption: takes data.table checks to see if it contains columns
# Args:       dataTable    - a data.table
#             columns      - a vector of column names
# Return:     TRUE/FALSE
###################################################################/
utils.data.table.containsColumns = function( dataTable, columns )
{
  if( !is.data.table( dataTable ) )
    stop( "dataTable must be a data.table")

  if( length( intersect( names( dataTable), columns ) ) != length( columns ) )
    return( FALSE )
  else
    return( TRUE );
}

###################################################################/
# Name:       utils.data.table.indexRepeatedKeys
# Descrption: takes data.table and a key and adds a new column which
#             is an index 1:N of
# Args:       dataTable    - a data.table
#             key          - a vector of key
#             indexColName - name of the column for the index
# Return:     NULL (dataTable is changed in place)
###################################################################/
utils.data.table.indexRepeatedKeys = function( dataTable, key, indexColName = "index", orderColName = NULL, orderIncreasing = TRUE )
{
  if( !length( key ) )
    stop( "Must give keys")

  if( !utils.data.table.containsColumns( dataTable, key ) )
    stop( "dataTable must contain all the columns in key");

  if( !is.null( orderColName ) )
  {
    if( !utils.data.table.containsColumns( dataTable, orderColName ) )
      stop( "dataTable must contain orderColName if non-null" )

    if( orderIncreasing == TRUE )
      keyOrder = c( key, orderColName )
    else
    if( orderIncreasing == FALSE )
    {
      dataTable[ , BEDGRAPH_INTERNAL_ORDERCOL := get( orderColName ) * - 1 ]
      keyOrder = c( key, "BEDGRAPH_INTERNAL_ORDERCOL"  )
    }
    else
      stop( "orderIncreasing must be TRUE/FALSE" )
  }
  else
    keyOrder = key;

  # order by the key
  setkeyv( dataTable, keyOrder )
  count = dataTable[ , .( UTILS_INTERNAL_COUNT = .N ), by = key ];

  # get a table containing repeat counts for each N
  sequences = list();
  Ns        = list();
  counts    = count[ , unique( UTILS_INTERNAL_COUNT ) ];
  for( k in 1:length(counts) )
  {
    sequences[[ k ]] = 1:counts[k];
    Ns[[ k ]]        = rep( counts[k], counts[k] )
  };
  temp    = data.table( index = unlist( sequences ), UTILS_INTERNAL_COUNT = unlist( Ns ) );
  indices = temp[ count, on = "UTILS_INTERNAL_COUNT", allow.cartesian=TRUE ]
  dataTable[, c( indexColName ) := list( indices[ , index ] ) ];

  if( orderIncreasing == FALSE )
    dataTable[ , BEDGRAPH_INTERNAL_ORDERCOL := NULL ]

}

###################################################################/
# Name:       utils.data.table.search
# Descrption: takes data.table and matches all rows which match a string in a sub-set of columns
# Args:       dataTable    - a data.table
#             pattern      - a character to match
#             columns      - a vector of column names or NULL is all columns
# Return:     data.table
###################################################################/
utils.data.table.search = function( dataTable, pattern, columns = NULL )
{
  if( !is.data.table( dataTable ) )
    stop( "dataTable must be a data.table")

  if( is.null( columns ) )
    columns = names( dataTable )

  ldt = dataTable[ ,lapply( .SD, function( x ) grepl( pattern, x, ignore.case = TRUE ) ), .SDcols = columns ]
  return( dataTable[ rowSums( ldt ) > 0 ] )
}

###################################################################/
# Name:       utils.data.table.stats.correlationMatrix
# Descrption: takes data.table and calculates a correlation matrix of the data
#             good for dealing with sparse data
# Args:       dataTable     - a data.table
#             indexCol      - column which defines the index for each matched data point
#             identifierCol - column which has the identifier (if N distinct values in this col then cov matrix is N*N )
#             valueCol      - column which has the value, if NULL then will assume 1 to give an incidence cor
# Return:     matrix
###################################################################/
utils.data.table.stats.correlationMatrix = function( dataTable, indexCol, identifierCol, valueCol = NULL, ignoreDuplicates = is.null( valueCol ), colOrder = NULL )
{
  N = length( dataTable[ , unique( get( indexCol ) ) ] )

  duplicateRows = ( dataTable[ ,.N ] != dataTable[ ,.N, by = c( indexCol, identifierCol ) ][ ,.N ] )
  if( ignoreDuplicates == FALSE & duplicateRows == TRUE )
      utils.throw( "dataTable contains multiple rows with same indexCol and identifierCol" )

  # if a valueCol is not given then add a column of 1s to get incidence correlation matrix
  defValCol = "INTERNAL_UTILS_DATA_TABLE_VALUE_COL"
  if( is.null( valueCol ) )
  {
    valueCol = defValCol;
    dataTable[ , c( valueCol ) := 1 ]
  }

  # calculate variances
  if( duplicateRows == FALSE )
    var = dataTable[ , .( s = sum( get( valueCol ) ), ss = sum( get( valueCol ) * get( valueCol ) ) ), by = identifierCol ][ , .(mean = s / N, sd = sqrt( ss / N - s * s / N / N ), id = get( identifierCol ) ) ]
  else
    var = dataTable[ , .( valueCol = max( get( valueCol ) ) ), by = c( indexCol, identifierCol ) ][ , .( s = sum( valueCol ), ss = sum( valueCol * valueCol ) ), by = identifierCol ][ , .(mean = s / N, sd = sqrt( ss / N - s * s / N / N ), id = get( identifierCol ) ) ]

   # calculate covariance
  if( duplicateRows == FALSE )
    covar = dataTable[ ,.( v1 = get( valueCol ), id1 = get( identifierCol ), index = get( indexCol ) ) ][ dataTable[ ,.( v2 = get( valueCol ), id2 = get( identifierCol ), index = get( indexCol ) ) ], on = "index", allow.cartesian = TRUE ][ ,.( covar = sum( v1 * v2 ) / N ), by = c( "id1", "id2" ) ]
  else
  {
    temp  = dataTable[ , .( valueCol = max( get( valueCol ) ) ), by = c( indexCol, identifierCol ) ]
    covar = temp[ ,.( v1 = valueCol, id1 = get( identifierCol ), index = get( indexCol ) ) ][ temp[ ,.( v2 = valueCol, id2 = get( identifierCol ), index = get( indexCol ) ) ], on = "index", allow.cartesian = TRUE ][ ,.( covar = sum( v1 * v2 ) / N ), by = c( "id1", "id2" ) ]
    remove( temp )
  }
  var = var[ ,.( mean1 = mean, sd1 = sd, id1 = id, dummy = 1 ) ][ var[ ,.( mean2 = mean, sd2 = sd, id2 = id, dummy = 1 ) ], on = "dummy", allow.cartesian = TRUE ]
  covar = covar[ var, on = c( "id1", "id2" ) ]
  utils.data.table.replaceNA( covar, columns = "covar" )

  # deal with zero covariances
  covar[ , covar :=  covar - mean1 * mean2 ]
  covar[ , covar := ifelse( sd1 == 0 & sd2 == 0, ifelse( covar < 0, -1, 1 ), ifelse( sd1 == 0 | sd2 == 0, sign( covar ), covar / sd1 / sd2) ) ]

  # now convert to a dense matrix
  covMat = dcast( covar, id1 ~ id2, fill = 0, value.var = "covar" )
  covMat[ , id1 := NULL ]
  covMat = as.matrix( covMat )
  rownames( covMat ) <- colnames( covMat )

   # clean up if added default data
  if( valueCol == defValCol )
    dataTable[ , c( valueCol ) := NULL ]

  # change order if necessary
  if( !is.null( colOrder ) )
  {
    currentCols = colnames( covMat )
    newCols     = c()
    nIdx        = 0
    for( col in colOrder )
    {
      cIdx = which( currentCols == col )
      if( length( cIdx) > 0 )
      {
        nIdx = nIdx + 1;
        newCols[ nIdx ] = cIdx
      }
    }
    newCols = c( newCols, setdiff( newCols, 1:length( currentCols ) ) )
    covMat  = covMat[ newCols, newCols ]
  }

  return( covMat )
}

###################################################################/
# Name:       utils.data.table.project
# Descrption: takes data.table and projects a set of colummns
# Return:     datat.able or vector
###################################################################/
utils.data.table.project = function( dataTable, columns, asVector = FALSE, allBut = FALSE )
{
  if( allBut == TRUE )
    columns = setdiff( names( dataTable ), columns )

  if( asVector == FALSE )
    return( dataTable[ , .SD, .SDcols = columns ] )
  else
  if( length( columns ) == 1 )
  {
    temp = utils.data.table.project( dataTable, columns )
    setnames( temp, columns, "col" )
    return( temp[ , col ] )
  }
  else
    utils.throw( "can only return a single column as a vector" )
}

###################################################################/
# Name:       utils.data.table.join.fullouter
# Descrption: a full outer join of 2 data.tables
# Return:     data.table
###################################################################/
utils.data.table.join.fullouter = function( dt1, dt2, on )
{
  if( length( on ) == 1 )
  {
    all = unique( c( utils.data.table.project( dt1, on, asVector = TRUE ), utils.data.table.project( dt2, on, asVector = TRUE ) )  )
    return( dt1[ dt2[ J( all ), on = on ], on = on ])
  }
  else
  {
    all = rbindlist( list( dt1[ ,.N, by = on ], dt2[ ,.N, by = on ] ), use.names = TRUE )[ ,.N, by = on ][ , .SD, .SDcols = on ]
    return( dt1[ dt2[ all, on = on ], on = on ] )
  }
}

###################################################################/
# Name:       utils.data.table.normalize
# Descrption: normalized values in column
# Return:     NULL
###################################################################/
utils.data.table.normailize = function( dt, cols = NULL, method = "mean" )
{
  if( is.null( cols ) )
    cols = names( dt )

 if( method == "mean" )
   dt[ , c( cols ) := lapply( .SD, function( x ) x * length( x ) / sum( x * 1.0 ) ), .SDcols = cols ]
  else
    utils.throw( "do not recognized method" )
}

