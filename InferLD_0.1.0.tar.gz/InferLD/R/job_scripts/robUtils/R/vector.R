###################################################################
# Name:       utils.vector.groupSum
# Descrption: takes vector and sums (blocked) groups of elements
# Return:     numeric vector
###################################################################
utils.vector.groupSum = function( vector, groupSize, interweaved = FALSE )
{
  nGroups = length( vector ) / groupSize
  if( nGroups != floor( nGroups ) )
    utils.throw( "the lengh of the vector must be a multiple of the groupSize" )

  return( colSums( matrix( vector, nrow = nGroups, ncol = groupSize, byrow = interweaved ) ) )
}

###################################################################
# Name:       inc
# Descrption: takes a number, increments by 1 and returns
#             in-efficient for big loops, useful for small loops
# Return:     NULL
###################################################################
inc = function( x )
{
  eval.parent( substitute( x <- x + 1 ) );
  return( x )
}
