reactiveValues = reactiveValues()

if( !exists( "cacheEnv" ) )
  cacheEnv = new.env()

###################################################################################/
# utils.shiny.element ####
###################################################################################/
utils.shiny.element = utils.class(
  classname = "utils.shiny.element",
  private = list(
    .id             = NULL,
    .ui             = NULL,
    .server         = NULL,
    .callBacks      = list()
  ),
  public = list(
    .reactiveValues = reactiveValues(),

    ###################################################################################/
    # initialize
    ###################################################################################/
    initialize = function( ui = NULL, server = NULL , callBacks = list(), reactiveValues = list() )
      {
        private$.id          <- UUIDgenerate()
        private$.ui          <- ui
        private$.server      <- server
        private$.callBacks   <- callBacks
        self$.reactiveValues <- reactiveValues
      },

    ###################################################################################/
    # runApp
    ###################################################################################/
    runApp = function() return( runApp( shinyApp( ui = self$ui, server = self$server ) ) ),

    ###################################################################################/
    # setRV
    ###################################################################################/
    setRV = function( name, value )
    {
      self$reactiveValues$setRV( name, value )
    },

    ###################################################################################/
    # getRV
    ###################################################################################/
    getRV = function( name )
    {
      return( self$reactiveValues$getRV( name ) )
    }

  ),

  active = list(
    ###################################################################################/
    # id
    ###################################################################################/
    id = function() return( private$.id ),

    ###################################################################################/
    # ui
    ###################################################################################/
    ui = function() return( private$.ui ),

    ###################################################################################/
    # server
    ###################################################################################/
    server = function() return( private$.server ),

    ###################################################################################/
    # callBacks
    ###################################################################################/
    callBacks = function() return( private$.callBacks ),

    ###################################################################################/
    # reactiveValues
    ###################################################################################/
    reactiveValues = function() return( self$.reactiveValues )
  )
);

##################################################################/
# Name:        utils.shiny.getLastEvent.clear
# Description: function for working out the last event of of a subest
###################################################################/
utils.shiny.getLastEvent.clear = function()
{
  if( exists( "UTILS_SHINY_APP_LASTEVENT", envir = cacheEnv ) )
    assign( "UTILS_SHINY_APP_LASTEVENT", NULL, envir = cacheEnv )
}

##################################################################/
# Name:        utils.shiny.getLastEvent
# Description: function for working out the last event of of a subest
###################################################################/
utils.shiny.getLastEvent = function( eventList, name )
{
  maxRows = 1e3;
  if( !exists( "UTILS_SHINY_APP_LASTEVENT", envir = cacheEnv ) )
  {
    lastEvent = data.table( NAME = rep( "", maxRows ), INDEX = rep( as.integer( 0 ), maxRows ), DETAILS = rep( "", maxRows ) )
    assign( "UTILS_SHINY_APP_LASTEVENT", lastEvent, envir = cacheEnv )
  }
  else
    lastEvent = get( "UTILS_SHINY_APP_LASTEVENT", envir = cacheEnv )

  nEvents = length( eventList );

  # add a new row to lastEvent if necessary
  if( lastEvent[ NAME == name ][ ,.N ] == 0 )
  {
    nextIdx = lastEvent[ ,.N ] - lastEvent[ NAME == "" ][ ,.N ] + 1;
    names   = rep( name, nEvents + 1 );

    if( nextIdx + nEvents > lastEvent[ ,.N ])
    {
      blankEvent = data.table( NAME = rep( "", maxRows ), INDEX = rep( 0, maxRows ), DETAILS = rep( "", maxRows ) )
      lastEvent  = rbindlist( list( lastEvent, blankEvent ), use.names = TRUE )
    }

    lastEvent[ nextIdx:( nextIdx + nEvents ), c( "NAME", "INDEX" ) := list( names, 0:nEvents ) ];
  }

  # turn event into a string for storing in the lastEvent table
  details = c();
  for( k in 1:nEvents)
    if( is.list( eventList[[ k ]]) )
      details[ k ] = utils.list.namedListToChar( eventList[[ k ]] )
  else
    details[ k ] = paste( as.character( eventList[[ k ]]), collapse = ":" )

  # ignore certain events
  ignoreEvents = c( "dragmode¶zoom", "dragmode¶pan", "dragmode¶select", "dragmode¶lasso" );
  for( k in 1:nEvents )
  {
    if( sum( ignoreEvents == details[ k ] ) > 0 )
      eventList[[ k ]] = NA  # use NA since if set last element of list to NULL it is dropped :(
  }

  # ignore events which have not happened yet
  nonNullIdxs = c();
  for( k in 1:nEvents )
    if( !is.null( eventList[[ k ]] ) &&  !is.na( eventList[[ k ]] ) )
      nonNullIdxs = c( nonNullIdxs, k )

  # most recent event deemed to be first one which has changed
  if( length( nonNullIdxs) >  0)
    for( k in 1:length( nonNullIdxs ) )
    {
      idx = nonNullIdxs[ k ];
      if( lastEvent[ NAME == name & INDEX == idx, DETAILS ] != details[ idx ])
      {
        lastEvent[ NAME == name & INDEX == idx, DETAILS := details[ idx ] ];
        lastEvent[ NAME == name & INDEX == 0,   DETAILS := as.character( idx ) ];
        assign( "UTILS_SHINY_APP_LASTEVENT", lastEvent, envir = cacheEnv )
        return( list( index = idx, event = eventList[[ idx ]] ) );
      }
    }

  # if no event has changed then the most recent event
  lastIdx = as.integer( lastEvent[ NAME == name & INDEX == 0, DETAILS ] );
  if( !is.null( lastIdx ) && !is.na( as.double( lastIdx ) ) )
  {
    details = lastEvent[ NAME == name & INDEX == lastIdx, DETAILS ];
    if( !is.null( details ) & is.character( details ) )
      return( list( index = lastIdx, event = utils.list.charToNamedList( details ) ) )
  }

  return( NULL );
};

##################################################################################/
# utils.shiny.layout.class ####
##################################################################################/
utils.shiny.layout.class <- utils.class(
  classname = "utils.shiny.layout.class",
  inherit   = utils.shiny.element,
  public    = list(
    ##################################################################################/
    # initialize
    ##################################################################################/
    initialize = function( elements )
    {
      # elements is a list (or list of lists) of shiny elements
      # outer list is for each row, inner lists are for elements within a row
      super$initialize()
      id = self$id;

      if( !is.list( elements ) )
        utils.throw( "elements must be a list or list of list of utils.shiny.element" )

      rows  = list()
      nrows = length( elements )
      for( row in 1:nrows )
      {
        if( is.list( elements[[ row ]] ) )
        {
          ncols  = length( elements[[ row ]] )
          width  = max( floor( 12 / ncols ), 1 )
          rowUis = list()
          for( col in 1:ncols )
            if( inherits( elements[[ row ]][[ col ]], "utils.shiny.element" ) )
              rowUis[[ col ]] = column( width, elements[[ row ]][[ col ]]$ui )
          else
            utils.throw( "chart must be of type utils.shiny.element" )
          rows[[ row ]] = fixedRow( rowUis )
        }
        else
          if( inherits( elements[[ row ]], "utils.shiny.element" ) )
            rows[[ row ]] = fixedRow( elements[[ row ]]$ui )
          else
            utils.throw( "each element must be of type utils.shiny.element" )
      }
      private$.ui = fluidPage( rows )

      # set up server
      server = function( input, output )
      {
        for( row in 1:nrows )
        {
          if( is.list( elements[[ row ]] ) )
          {
            for( col in 1:ncols )
              elements[[ row ]][[ col ]]$server( input, output )
          }
          else
            elements[[ row ]]$server( input, output )
        }
      }
      private$.server = server
    }
  )
)

##################################################################################/
# utils.shiny.layout ####
##################################################################################/
utils.shiny.layout <- function( elements )
{
  return( utils.shiny.layout.class$new( elements ) )
}

##################################################################################/
# utils.shiny.layout.genomic ####
##################################################################################/
utils.shiny.layout.genomic <- function( elements, linkCharts = TRUE )
{
  if( linkCharts )
  {
    charts = unlist( elements )
    for( k in length( charts ):1 )
      if( !utils.class.interface.implements( charts[[ k ]], "utils.plotly.genomic.interface" ) &&
          !utils.class.interface.implements( charts[[ k ]], "utils.plotly.genomicRange.interface" )
      )
        charts[[ k ]] = NULL

    nCharts = length( charts )
    if( nCharts > 1 )
      for( i in 1:( nCharts - 1 ) )
        for( j in (i+1):nCharts )
          utils.plotly.genomic.link( charts[[ i ]], charts[[ j ]], bothWays = TRUE )
  }

  return( utils.shiny.layout.class$new( elements ) )
}


#
# ##################################################################################/
# # utils.shiny.text
# ##################################################################################/
# utils.shiny.text <- R6Class(
#   "utils.shiny.text",
#   inherit = utils.shiny.element,
#   public  = list(
#     ##################################################################################/
#     # initialize
#     ##################################################################################/
#     initialize = function( text = "", editable = FALSE, label = "" )
#     {
#       super$initialize()
#       id = self$id;
#       dummyId = paste( "DUMMY", id, sep = "")
#
#       if( !editable )
#       {
#          # set up ui
#      #   private$.ui = htmlOutput( id )
#
#         private$.ui = fluidRow(
#           htmlOutput( id ),
#           htmlOutput( dummyId )
#         )
#
#         this = self;
#
#         # set up server
#         private$.server = function( input, output, session )
#         {
#           print( self$id)
#           print( this$id)
#           this$text = text
#           output[[ id ]] = renderText( { this$text })
#        #   output[[ dummyId ]] = renderText({ this$text = text; NULL } )
#
#         }
#       }
#       else
#       {
#         # set up ui
#         private$.ui = fluidRow(
#           textInput( id, label = label ),
#           htmlOutput( dummyId )
#         )
#
#         self$text = text
#         this = self;
#
#         # set up server
#         private$.server = function( input, output, session )
#         {
#           update = reactive( { this$text = input[[ id ]] } )
#           output[[ dummyId ]] = renderText({ update(); this$text; NULL } )
#         }
#       }
#     }
#   ),
#   active = list(
#     ##################################################################################/
#     # text
#     ##################################################################################/
#     text = function( value )
#     {
#       tag = paste( self$id, "text", sep = "_" )
#       if( missing( value) )
#       {
#         print( sprintf( "get %s", tag))
#         return( reactiveValues$tag )
#       }
#       else
#       {
#         print( sprintf( "set %s", tag))
#         reactiveValues$tag = value
#       }
#     }
#   )
# )
#
