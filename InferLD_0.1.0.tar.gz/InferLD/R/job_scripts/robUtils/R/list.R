###################################################################
# Name:       utils.list.namedListToChar
# Descrption: takes a named list of characters/doubles and converts it to a singe character
# Args:       list
# Return:     character
###################################################################
utils.list.namedListToChar = function( list, delimiter = "¶" )
{
  if( !is.list( list ) )
    stop( "list must be a list" )

  names  = names( list )
  values = as.character( list );
  if( is.null(names) )
    stop( "list must be a named list" )

  char = paste( c( names, values ), collapse = delimiter );

  if( stringr::str_count( char, pattern = delimiter ) != 2 * length( names ) - 1 )
    stop( sprintf( "list cannot contain the delimiter character %s", regex = delimiter ) )

  return( char )
}

###################################################################
# Name:       utils.list.charToNamedList
# Descrption: inverse of utils.list.charToNamedList
# Args:       char
# Return:     namedlist
#             if type is set to NULL then we convert to a numeric
#             value of possible, failing that will convert to a character
###################################################################
utils.list.charToNamedList = function( char, delimiter = "¶", type = NULL )
{
  if( length( char ) > 1 )
    stop( "character must be of a single length" )

  bits = strsplit( char, delimiter )[[1]];
  n    = length( bits ) / 2;

  if( round( n ) != n )
    stop( sprintf( "char must contain the delimiter %s an odd number of times", delimiter ) )

  if( is.null( type ) )
  {
    listChar = as.list( bits[ ( n + 1):( 2 * n ) ] )
    list     = as.list( suppressWarnings( as.double( bits[ ( n + 1):( 2 * n ) ] ) ) )
    list     = ifelse( is.na( list ), listChar, list )
  }
  else if( type == "character" )
    list = as.list( bits[ ( n + 1):( 2 * n ) ] )
  else
  if( type == "double" )
    list = as.list( suppressWarnings( as.double( bits[ ( n + 1):( 2 * n ) ] ) ) )
  else

    stop( "only suports type of character and double" );

  return( setNames( list, bits[ 1:n ]) )
}
