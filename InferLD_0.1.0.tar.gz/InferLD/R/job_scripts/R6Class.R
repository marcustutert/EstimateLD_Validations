###################################################################################/
# utils.class
#
# add interfaces to R6 class infrastructure
###################################################################################/
utils.class = function(
  classname = NULL,
  public    = list(),
  private   = list(),
  active    = list(),
  inherit   = NULL,
  interfaces = list(),
  lock_objects = TRUE,
  class      = TRUE,
  portable   = TRUE,
  lock_class = FALSE,
  cloneable  = TRUE,
  parent_env = parent.frame(),
  lock
)
{
  # check to see an inherited class has been created by utils.class
  if( !is.null( inherit ) )
  {
    if( inherit$inherit != "utils.class.parent" )
      utils.throw( "inherited classes must be created by utils.class (i.e. so have inherited utils.class.class)" )
  }
  else
    inherit = utils.class.class

  # create an environment in the parent_env which just contains the name of the inherited generator
  envir = new.env( parent = parent_env )
  utils.class.parent = inherit
  assign( "utils.class.parent", utils.class.parent, envir = envir )

  # add interfaces to R6 class
  if( !is.list( interfaces ) )
    interfaces = list( interfaces )

  interfaceNames = c()
  nInterfaces    = length( interfaces )
  if( nInterfaces )
  {
    publicNames  = names( public )
    privateNames = names( private )
    activeNames  = names( active )

    for( k in 1:nInterfaces )
    {
      if( interfaces[[ k ]]$inherit != "utils.class.interface.class" )
        utils.throw( "interfaces must be inherited from utils.class.interface.class" )

      iName = interfaces[[ k ]]$classname

      # check public methods first
      for( iPublic in list( interfaces[[ k ]]$public_methods, interfaces[[ k ]]$public_fields ) )
        if( !is.null( iPublic ) )
          for( j in 1:length( iPublic ) )
          {
            iMethName =names( iPublic )[ k ]
            if( iMethName == "clone" )
              next();
            if( !( iMethName %in% names( public ) ) )
              utils.throw( sprintf( "must implement public method %s on interface %s", iMethName, iName ) )
          }

      # check private methods
      for( iPrivate in list( interfaces[[ k ]]$private_methods, interfaces[[ k ]]$private_fields ) )
        if( !is.null( iPrivate ) )
          for( j in 1:length( iPrivate ) )
          {
            iMethName = names( iPrivate )[ k ]
            if( !( iMethName %in% names( private ) ) )
              utils.throw( sprintf( "must implement private method %s on interface %s", iMethName, iName ) )
          }

      # check active methods
      iActive = interfaces[[ k ]]$active
        if( !is.null( iActive ) )
          for( j in 1:length( iActive ) )
          {
            iMethName = names( iActive )[ k ]
            if( !( iMethName %in% names( active ) ) )
              utils.throw( sprintf( "must implement active field %s on interface %s", iMethName, iName ) )
          }

      interfaceNames[ length( interfaceNames ) + 1 ] = iName
    }
  }
  private$.INTERNAL_INTERFACES = c( inherit$private_fields$.INTERNAL_INTERFACES, interfaceNames )
  active$interfaces = function() return( private$.INTERNAL_INTERFACES )

  return( R6Class( classname = classname, public = public, private = private, active = active, inherit = utils.class.parent, lock_objects = lock_objects, class = class, portable = portable, lock_class = lock_class, cloneable = cloneable, parent_env = envir, lock ))
}

###################################################################################/
# utils.class.class ####
#
# add interfaces to R6 class infrastructure
###################################################################################/
utils.class.class = R6Class(
  "utils.class.class",
  private = list(
    .INTERNAL_INTERFACES = c()
  ),
  active = list(
    interfaces = function( val ) if( is.null( val ) ) return( private$.INTERNAL_INTERFACES ) else utils.throw( "cannot update interface list manually" )
  )
)

###################################################################################/
# utils.class.interface.class ####
#
# add interfaces to R6 class infrastructure
###################################################################################/
utils.class.interface.class = R6Class(
  "utils.class.interface.class",
  public = list(
    is.interface  = function() return( TRUE )
  )
)

###################################################################################/
# utils.class.interface
# add interfaces to R6 class infrastructure
###################################################################################/
utils.class.interface = function(
  interfacename = NULL,
  public = list(),
  private = list(),
  active = list()
)
{
  return( R6Class( interfacename, public = public, private = private, active = active, inherit = utils.class.interface.class ) )
}

###################################################################################/
# utils.class.interface.implements
# checks to see if an interface has been implemented
# check private internal variable directly to prevent accidental name mismatches
###################################################################################/
utils.class.interface.implements = function(
  object,
  interfaceName
)
{
  if( !is.R6( object ) | !inherits( object, "utils.class.class") )
    utils.throw( "object must be from a class generated by utils.class()" )

  if( is.null( object$.__enclos_env__$private$.INTERNAL_INTERFACES ) )
    utils.throw( "object must be from a class generated by utils.class()" )

  return( length( intersect( object$.__enclos_env__$private$.INTERNAL_INTERFACES, interfaceName ) ) == 1 )
}
