#' @importFrom stats qgamma
#' @importFrom stats rbinom

Gamma_Weight_States = function(weights_resolution,
                               ref_allele_matrix,
                               Fst){

  #Create a function which creates the actually states of the gamma weights (drawn from quantiles)
  nhaps = nrow(ref_allele_matrix)
  #Generate from quantiles with scale = 1 (for future Dirichlet marginalization)
  Gamma_Quantiled_Weights = qgamma(p = (1:weights_resolution)/(1+weights_resolution), shape = 1 / ( nhaps * (Fst/(1-Fst))), scale = ( nhaps * (Fst/(1-Fst))) )
  Gamma_Quantiled_Weights = Gamma_Quantiled_Weights[is.finite(Gamma_Quantiled_Weights) & Gamma_Quantiled_Weights > 0 ]
  #Gamma_Quantiled_Weights = seq(0.1,100,1/weights_resolution)
  return(Gamma_Quantiled_Weights)
}

weight_update = function(ref_allele_matrix,
                         weight_matrix,
                         Gamma_Weights_States,
                         row_update){

  #ref_allele_panel needs to be all 0's and 1's, has to be dimensions nhaps by nsnps
  nsnps = ncol(ref_allele_matrix)
  nhaps = nrow(ref_allele_matrix)
  #Condition that if we aren't on the first haplotype (idx) that we are updating (row_update <=1), we can do an incremental update increase
  if (row_update < 2) {
    #This is the slow way of doing the weights (lots of extra calculations that are un-needed!)
    x1_sums            = colSums(weight_matrix*ref_allele_matrix) - (weight_matrix[row_update,] * ref_allele_matrix[row_update,])
    x1_matrix          = matrix(0,nrow =length(Gamma_Weights_States),ncol =length(x1_sums))
    for (i in 1:length(x1_sums)) {
      x1_matrix[,i]    = x1_sums[i]
    }
    x2                 = outer(Gamma_Weights_States, ref_allele_matrix[row_update,], FUN ='*')
    B                  = x1_matrix + x2
    S                  = colSums(weight_matrix)-weight_matrix[1,]
    A                  <<- outer(S,Gamma_Weights_States, FUN='+')
    x1_matrix          <<- as.matrix(replicate(length(Gamma_Weights_States), x1_sums))
    allele_frequencies = t(x1_matrix)
    allele_frequencies = t(B)/A
    #Return the allele frequencies
    return(allele_frequencies)
  }

  #Incremental update, given that we've already stored some of the totals from above (aka we are on at least the 2nd haplotype being updated!)
  #This means we have started to populate our path matrix (nsnps x nhaps)
  else{
    #First thing that will be different is the column sums (S) will be changed
    #Rather than taking the full column sums again, there will be only two differences between (S and S*, previous and updated version)
    A_idx_removed           = weight_matrix[row_update,]
    A_idx_minus_one_removed = weight_matrix[(row_update-1),]

    #We add the previous row (idx-1) and remove the current row weights (idx)
    A_weights_differences = A_idx_minus_one_removed - A_idx_removed
    #Sweep across the column sums, keep this value globally
    A = sweep(A, 1, A_weights_differences, "+")

    #Incremental updates for x1
    x1_idx_removed                = weight_matrix[(row_update-1),] * ref_allele_matrix[(row_update-1),]
    x1_idx_minus_one_removed      = weight_matrix[row_update,] * ref_allele_matrix[row_update,]

    #We add the previous row (idx-1) and remove the current row weights (idx)
    x1_weights_differences = x1_idx_minus_one_removed - x1_idx_removed

    #Sweep across the column sums, keep this value globally
    x1_matrix = sweep(x1_matrix, 1, x1_weights_differences, "-")
    #Transpose this matrix
    x1_matrix = t(x1_matrix)
    #Incremental updates for x2
    x2                 = outer(Gamma_Weights_States, ref_allele_matrix[row_update,], FUN ='*')

    #Carry out the matrix division with incremental updated matrices to get the allele frequencies
    if (!identical(dim(x1_matrix),dim(x2))) {
      x2 = t(x2)
      B                  = x1_matrix + x2
      allele_frequencies = B/A
    }
    else{
      B                  = x1_matrix + x2
      allele_frequencies = t(B)/A
    }
  }
  return(allele_frequencies)
}

allele_frequency_update = function(ref_allele_matrix,
                                  weight_matrix,
                                  Gamma_Weights_States,
                                  row_update){

  #ref_allele_panel needs to be all 0's and 1's, has to be dimensions nhaps by nsnps
  nsnps = ncol(ref_allele_matrix)
  nhaps = nrow(ref_allele_matrix)

  allele_frequencies_slow = matrix(data = NA, nrow = length(Gamma_Weights_States), ncol = nsnps)
  for (i in 1:ncol(allele_frequencies_slow)) {
    #Remove the correct row
    #weight_matrix_remove_row = (weight_matrix[-row_update,])

    #Replicate over that SNP column
    weight_matrix_replicated = matrix(weight_matrix[-row_update,i], nrow=length(weight_matrix[-row_update,i]), ncol=length(Gamma_Weights_States), byrow=TRUE)

    #Add in the new column of quantiles weight states AT THE RIGHT ROW that we have missed
    weight_matrix_modified   = rbind(weight_matrix_replicated[1:(row_update-1),],Gamma_Weights_States,weight_matrix_replicated[-(1:(row_update-1)),])
    allele_frequencies_slow[,i] = colSums(weight_matrix_modified * ref_allele_matrix[, i]) / colSums(weight_matrix_modified)

  }
  return(t(allele_frequencies_slow))
}

#' @export
prob_sigma_given_frequency = function(allele_frequency_matrix,
                                      se_observed,
                                      noise,
                                      j,
                                      likelihood_toggle,
                                      nSamples){
  #Turning off Likelihood to test recovery of priors etc
  if (likelihood_toggle == FALSE){
    states = ncol(allele_frequency_matrix)
    snps   = nrow(allele_frequency_matrix)
    prob_normalized = matrix(data = 1/states,nrow = states, ncol = snps)
    return(prob_normalized)
  }
  #Keep the normal likelihood formulas
  if (likelihood_toggle == TRUE){
    #Calculate ratios of true to implied SE's
    #implied_het_weights = 1/2*allele_frequency_matrix*(1-allele_frequency_matrix)
    implied_se          = 1/(allele_frequency_matrix*(1-allele_frequency_matrix))
    ratio               = se_observed/implied_se
    prob_observed       = t(dgamma(ratio, shape=noise, rate=noise, log=T))  #Keep this in log space

    #Now use logMaxExp trick...
    #Find max in in each column,
    max_prob_column           = colMaxs(prob_observed)
    #Subtract this value in each column
    prob_observed_max_diff    = sweep(prob_observed, 2, max_prob_column, FUN = '-')

    #Exponentiate everything
    prob_observed_real        = exp(prob_observed_max_diff)

    #Normalize probabilities such that they all sum to one...
    prob_sum        = colSums(prob_observed_real)
    prob_normalized = sweep(prob_observed_real, 2, prob_sum, FUN = '/')

    #Hacky fix for now, add some small eps value (1e-10) to all columns then renormalize
    prob_normalized[prob_normalized<1e-100] <- 1e-10
    #Renormalize
    prob_normalized = sweep(prob_normalized, 2, prob_sum, FUN = '/')
    prob_sum        = colSums(prob_normalized)
    return(prob_normalized)
    }
}

#' @export
forward_pass = function(allele_frequency_matrix,
                        diag_transition)
{
    #Define a few constants to make notation easier below
    states = nrow(allele_frequency_matrix)
    snps   = ncol(allele_frequency_matrix)
    if (snps > 1) { #Assume we need to do HMM like algorithims
      #Diag_transition gives the value of going from state i->i (let's make it high for now)
      c = (1-diag_transition)/(states-1)
      a = diag_transition - c
      #Create a forward pass matrix, which has dimensions # of gamma quantile states by # of SNPs
      forward_pass_matrix = matrix(nrow = states, ncol= snps)
      pi_initial = rep(1/states,states)
      for(k in 1:states){
        forward_pass_matrix[k,1] = pi_initial[k] * allele_frequency_matrix[k,1]
      }
      #Normalize the first column of probabilities
      forward_pass_matrix[,1] = forward_pass_matrix[,1]/sum(forward_pass_matrix[,1])

      fp0 = forward_pass_matrix[,1]
      for(t in 1:(snps-1)){
        #Sum the mixed states as well as the averaging factor
        fp1 = c+ (fp0*a)
        #Now multiply by the observed probability at the length in the sequence
        fp1 = ( c+ (fp0*a)) * allele_frequency_matrix[,t+1]
        #Normalize and scale the probabilities
        fp0 = fp1/sum(fp1)
        fp0[is.nan(fp0)] <- 0
        forward_pass_matrix[,t+1] = fp0
      }
    }
  else{
    forward_pass_matrix = allele_frequency_matrix
  }
  return(forward_pass_matrix)
}

#' @export
sample_HMM_path = function(forward_pass_matrix,
                           diag_transition,
                           j,
                           row_update,
                           weight_matrix,
                           Gamma_Quantiled_Weights,
                           genetic_map){

    #Writing a function that samples a single path backwards through the forward algorithim matrix posteriors
    #Define a few constants to make notation easier below
    states      = nrow(forward_pass_matrix)
    snps        = ncol(forward_pass_matrix)
    recomb_rate = 1 - diag_transition #This is a vector of length nsnps-1
    #Initialize path trace vector
    path = rep(NA,snps)
    if ( snps > 1 ) {
      if (genetic_map == TRUE) {

        state_switch_transition = (1 - diag_transition) / ( states - 1 )
        #Start with last column, pick the state that we will be starting in
        path[snps] = sample( x = 1:states, size = 1, prob =  forward_pass_matrix[,snps]/sum(forward_pass_matrix[,snps]))
        #Now loop back through all the columns to get the full backtrace
        for (i in rev(seq(snps:1))[-length(snps)]) {
          a_ij            = rep(state_switch_transition[i],nrow(forward_pass_matrix))
          a_ij[path[i+1]] = diag_transition
          probabilities   = a_ij * forward_pass_matrix[,i]
          probabilities   = probabilities/sum(probabilities)
          path[i] = sample( x = 1:states, size = 1, prob = probabilities)
        }
      }
      if (genetic_map == FALSE)
      {
        #Sqmple the first state going backwards.
        prob        = forward_pass_matrix[,snps]/sum(forward_pass_matrix[,snps])
        path[snps]  = sample( x = 1:states, size = 1, prob =  forward_pass_matrix[,snps]/sum(forward_pass_matrix[,snps]))
        #While loop will keep moving backwards until we have filled up path with numbers and have no more NA's
        while (any(is.na(path)) == TRUE) {

          #Generate probability from uniform distribution
          prob = runif(n = 1, min = 0, max = 1)

          #Store the position of the first non NA value in our path vector
          NonNAindex <- which(!is.na(path))
          firstNonNA <- min(NonNAindex) #This tells us where on our path we have gotten to trace-wise

          #Subset the forward pass matrix given what last state we are in the trace, we want that full state row back in time
          forward_matrix_subset_state = forward_pass_matrix[path[firstNonNA],(firstNonNA-1):1]

          #Calculate digammas and generate one for each possible jump (k of these digammas)
          digamma_vector = ((forward_matrix_subset_state * (1-recomb_rate))/(recomb_rate/(states-1)+forward_matrix_subset_state*(1-(states*recomb_rate/(states-1)))))

          #Use exp(cumsum(log(digamma_k))) trick to get CDF
          #p_k gives us our CDF probability values for moving given we haven't moved yet!
          p_k             = 1-exp(cumsum(log(digamma_vector)))
          switch_position = which.max((p_k-prob)) - 1

          #Find the switch position by looking up nearest value of our probability in our CDF vector
          if( prob > max( p_k ) | sum(is.na(path)) < switch_position ) {
            path[1:(firstNonNA-1)] = rep(path[firstNonNA],firstNonNA-1) } #Stay in the same state all the way back
          else
          {
            #If we switch right away we need to consider this condition
            if (switch_position == 0) {
              state_prob = forward_pass_matrix[-path[firstNonNA],firstNonNA-switch_position]/sum(forward_pass_matrix[-path[firstNonNA],firstNonNA-switch_position])
              if(any(is.na(state_prob))){
                state_prob = rep(1/(states-1),states-1)}
              #Then we want to move to a new state after this and repeat
              path[firstNonNA-1] = sample( x = (1:states)[-path[firstNonNA]], size = 1, prob = state_prob)
            }
            else
            {
              #We want to repeat the last traced path state, a 'switch number' of times
              path[(firstNonNA-switch_position):(firstNonNA-1)] = rep(path[firstNonNA], switch_position)
              #We also want to remove the chance of being in the same state as a possibility (since we are going from i->j)
              state_prob = forward_pass_matrix[-path[firstNonNA],firstNonNA-switch_position]/sum(forward_pass_matrix[-path[firstNonNA],firstNonNA-switch_position])
              #Then we want to move to a new state after this and repeat
            }
          }
        }
      }
    }
  else{ #This is if we have only one SNP to consider (no need to do this sampling trick)
    path = sample( x = (1:states), size = 1, prob = forward_pass_matrix )
  }
  #Return our path vector at the end
  return(path)
}

#' @export
#Create a function that actually does the Gibbs Sampling (We will need something like this to perform the incremental updates)
#We want to return  the Gibbs implied allele frequency matrices
Allele_Freq_Check = function(recomb_rate, nSamples, weights_resolution, ref_allele_matrix, Fst, observed_sigma_b, alpha){

  #Get the nsnps and nhaps from ref_allele_matrix
  nsnps = ncol(ref_allele_matrix)
  nhaps = nrow(ref_allele_matrix)

  #Generate the Gamma Quantiled Weight Space
  Gamma_Quantiled_Weights = Gamma_Weight_States(weights_resolution = weights_resolution, ref_allele_matrix = ref_allele_matrix, Fst = Fst)

  #Uniformly draw weights from the quantiles for each SNP (draw number of weights equal to nhaps)
  constant_weight = Gamma_Quantiled_Weights[sample(x = 1:length(Gamma_Quantiled_Weights),size = 1,replace = TRUE,prob = NULL)]
  weight_matrix   = matrix(data = constant_weight, nrow = nhaps, ncol = nsnps)
  #weight_matrix = matrix( sample(Gamma_Quantiled_Weights, size = nhaps*nsnps, replace = TRUE, prob = NULL), ncol = nsnps, nrow = nhaps, byrow = TRUE )

  #Initialize the Gibbs Matrices
  Gibbs_Allele_Freq        = matrix(data = NA, nrow = nsnps, ncol = nSamples)
  weights_matrix_sum       = colSums(weight_matrix)
  if (length(weight_matrix_sum) == 1) {
    weight_matrix_normalized    = weight_matrix/weight_matrix_sum
  }
  else{
    weight_matrix_normalized      = weight_matrix %*% diag(1/weight_matrix_sum)
  }
  Gibbs_Allele_Freq[,1]           = colSums(ref_allele_matrix*weight_matrix_normalized)

  for (j in 2:nSamples) {
    #cat( sprintf("\r%d", j))
    for (idx in 1:nhaps){

      weight_increment = allele_frequency_update(ref_allele_matrix = ref_allele_matrix, weight_matrix = weight_matrix, Gamma_Weights_States = Gamma_Quantiled_Weights, row_update = idx)
      #Use the function for prob given the implied sigma_b
      #Get the forward pass through this matrix
      forward_pass_matrix   = forward_pass(allele_frequency_matrix = prob_normalized, diag_transition = 1-recomb_rate)
      path                  =  sample_HMM_path(forward_pass_matrix = forward_pass_matrix, diag_transition = 1-recomb_rate)
      # #Pick out the correct weights, given the path states, path is a vector
      weight_matrix[idx,] = Gamma_Quantiled_Weights[path]
    }
    #Get the sample averages for the allele frequencies
    weights_matrix_sum       = colSums(weight_matrix)
    if (length(weight_matrix_sum) == 1) {
      weight_matrix_normalized    = weight_matrix/weight_matrix_sum
    }
    else{
      weight_matrix_normalized      = weight_matrix %*% diag(1/weight_matrix_sum)
    }
    Gibbs_Allele_Freq[,j]    = colSums(ref_allele_matrix*weight_matrix_normalized)
  }

  #Return the matrix for the calculation of the Gibbs implied allele frequencies
  return(Gibbs_Allele_Freq)
}

#' @export
Gibbs_Sampling_HW_Array = function(recomb_rate, #Vectorized
                                   nSamples,
                                   weights_resolution,
                                   ref_allele_matrix,
                                   Fst,
                                   se_observed, #This is the GWAS SE NOT THE VARIANCE == SE^2 (take from Gil generation)
                                   alpha,
                                   likelihood_toggle,
                                   genetic_map,
                                   chain_likelihood)
{
  #Get the nsnps and nhaps from ref_allele_matrix
  ref_allele_matrix = as.matrix(ref_allele_matrix) #Convert to matrix
  nsnps = ncol(ref_allele_matrix)
  nhaps = nrow(ref_allele_matrix)

  #Initialize the array that will store each full sweeps haplotyped updates
  Gibbs_Array = array(rep(NA,nsnps*nSamples*nhaps), dim = c(nhaps,nsnps,nSamples))

  #Generate the Gamma Quantiled Weight Space
  Gamma_Quantiled_Weights = Gamma_Weight_States(weights_resolution = weights_resolution,
                                                ref_allele_matrix  = ref_allele_matrix,
                                                Fst                = Fst)

  #Uniformly draw weights from the quantiles for each SNP (draw number of weights equal to nhaps)
  #constant_weight = Gamma_Quantiled_Weights[2]
  #weight_matrix   = matrix(data = constant_weight, nrow = nhaps, ncol = nsnps)
  #Draw from a very skewed distribution of weights
  weight_matrix = matrix(sample(Gamma_Quantiled_Weights,
                                   size    = nhaps*nsnps,
                                   replace = TRUE,
                                   prob    = NULL),
                            ncol = nsnps,
                            nrow = nhaps,
                            byrow = TRUE)
  #Now assign the weights to the Gibbs_Array
  Gibbs_Array[,,1]    = weight_matrix
  #Assign likelihoods
  log_likelihood               =  c()
  #Assign AF
  inferred_af_given_weights     = matrix(data = NA, nrow = nsnps, ncol = (nSamples))
  weight_matrix_sum             = (colSums(weight_matrix))
  #Deal with situation where vector has length one
  if (length(weight_matrix_sum) == 1) {
    weight_matrix_normalized    = weight_matrix/weight_matrix_sum
  }
  else{
  weight_matrix_normalized      = weight_matrix %*% diag(1/weight_matrix_sum)
  }
  # #Transform normalized weights to become allele frequencies given reference panel
  inferred_af_given_weights[,1] = colSums(weight_matrix_normalized * ref_allele_matrix)
  implied_se                    = 1/(inferred_af_given_weights[,1]*(1-inferred_af_given_weights[,1]))
  ratio                         = se_observed/implied_se
  log_likelihood[1]             = sum(dgamma(ratio, shape=alpha, rate=alpha, log=T)) #Sum across all variants (log likelihood)
  #Find chosen states (w no recombination)
  chosen_states                 = matrix(data = NA, nrow = nhaps, ncol = (nSamples))

  #Store # of recombination Events, and store which Haps/SNPs/Sample we change paths on
  recomb_events       = array(data = NA, dim = c(nhaps,nsnps,nSamples)) #Dimensions nhaps x nsnps x nsamples

  for (j in 2:nSamples) {
    #Loop randomly
    #oo = sample(nhaps)
    for (idx in 1:nhaps)  {
      #idx = oo[idx]
      #cat( sprintf("\r%d", idx))
      weight_increment = allele_frequency_update_c(ref_allele_matrix      = ref_allele_matrix,
                                                   weight_matrix          = weight_matrix,
                                                   Gamma_Weights_States   = Gamma_Quantiled_Weights,
                                                   row_update             = idx)
      #Use the function for prob given the implied sigma_b
      prob_normalized = prob_sigma_given_frequency(allele_frequency_matrix = weight_increment,
                                                   se_observed             = se_observed,
                                                   noise                   = alpha,
                                                   j                       = j,
                                                   nSamples                = nSamples,
                                                   likelihood              = likelihood_toggle)

      #Get the forward pass through this matrix
      forward_pass_matrix   = forward_pass_c(allele_frequency_matrix = prob_normalized,
                                           diag_transition         = 1-recomb_rate)
      #Sample through the forward matrix backwards (pass)
      path                  = sample_HMM_path(forward_pass_matrix = forward_pass_matrix,
                                              diag_transition     = 1-recomb_rate,
                                              j                   = j,
                                              row_update          = idx,
                                              weight_matrix       = weight_matrix,
                                              Gamma_Quantiled_Weight,
                                              genetic_map         = genetic_map)
      # Pick out the correct weights, given the path states, path is a vector
      weights_new                              = Gamma_Quantiled_Weights[path]
      #Change to data table object for speed
      weight_matrix[idx,]                      = weights_new
      # Look at when the path changes across the SNPs (for that given haplotype)
      #recomb_events_index                      = which(diff(path) != 0) #Stores which SNPs at this haplotype update and sample number do we have recomb.
      #recomb_events[idx,recomb_events_index,j] = 1 #Store the fact that it does indeed change
    }
    #browser()
      #Store weights in the Gibbs array
      Gibbs_Array[,,j]         = weight_matrix
      if (chain_likelihood == TRUE) { #Output graph of the log-likelihood given the weights we have inferred up to that point
      #Transform weights to be normalized
      weight_matrix_sum             = colSums(weight_matrix)
      if (length(weight_matrix_sum) == 1) {
        weight_matrix_normalized    = weight_matrix/weight_matrix_sum
      }
      else{
        weight_matrix_normalized      = weight_matrix %*% diag(1/weight_matrix_sum)
      }
      # #Transform normalized weights to become allele frequencies given reference panel
      inferred_af_given_weights[,j] = colSums(weight_matrix_normalized * ref_allele_matrix)
      implied_se                    = 1/(inferred_af_given_weights[,j]*(1-inferred_af_given_weights[,j]))
      ratio                         = se_observed/implied_se
      log_likelihood[j]             = sum(dgamma(ratio, shape=alpha, rate=alpha, log=T)) #Sum across all variants (log likelihood)

      #Now we want to ask for each full Gibbs sweep, what are the weight states we ended up choosing
      chosen_states[,j]             = match(weight_matrix[,1],Gamma_Quantiled_Weights)
      }
  }
  #Return the matrix for the calculation of the Gibbs implied allele frequencies
  return(list(Gibbs_Array,recomb_events,log_likelihood,inferred_af_given_weights))
}
find_recomb_hotspots = function(recomb_events,
                                moving_avg_window = 5,
                                recomb_threshold  = 3){
  #This function will take in a list of recombination events (scaled?) from the weight inference process
  #Outputs a list of recombination hotspots (as a matrix (start:end))
  #Recomb events is a matrix of dimensions (nhaps x nsnps x nSamples (post burnIn))
  nsnps    = dim(recomb_events)[2]
  nhaps    = dim(recomb_events)[1]
  nSamples = dim(recomb_events)[3]

  #Now we want to average out the number of events across the nhaps
  recomb_events_haps = colSums(recomb_events,
                               na.rm = TRUE,
                               dims = c(1))
  recomb_events_avg  = rowMeans(recomb_events_haps)

  #Now we can tak this and look at the rolling average across the region of recomb. events
  moving_avg_recomb    <- function(x, n = moving_avg_window){filter(x, rep(1 / n, n), sides = 2)}
  recomb_events_mov_avg = moving_avg_recomb(recomb_events_avg, n = moving_avg_window)

  #Now that we have the smoothed regression line, we are interested in finding where the peaks are
  #Easiest thing to do is just find whenever recomb hotspots > some number
  recomb_above_thresh  = which(recomb_events_mov_avg > 3)
  recomb_hotspots_list = split(recomb_above_thresh, cumsum(c(1, diff(recomb_above_thresh) != 1)))
  return(recomb_hotspots_list)
}

#This function will take in some genetic map (from 1000G) and output a new list of the recombination rate which will then be used to
#Match the transition rates within the HMM
genetic_map_hotspots = function(genetic_map,
                                average_window   = 5,
                                hotspot_rate_min = 5, #How high does a hot-spot need to be considered one
                                start_position,
                                end_position,
                                nhaps_reference  = 1000,#
                                directory){
  moving_avg_recomb    <- function(x, n = moving_avg_window){filter(x, rep(1 / n, n), sides = 2)}
  start_index            = which.min(abs(genetic_map$position-start_position)) -1
  end_index              = which.min(abs(genetic_map$position-end_position)) + 1 #Add one to go over
  recomb_events_mov_avg  = moving_avg_recomb(genetic_map$COMBINED_rate.cM.Mb.[(start_index):(end_index)], n = average_window)
  recomb_scaled_hotspots = replace(recomb_events_mov_avg, recomb_events_mov_avg < 5,0)
  transition_rates       = rep(NA,length(genetic_map$position[(start_index-1):(end_index+1)]))
  transition_rates[which(recomb_scaled_hotspots == 0)] = 1e-100   #Coldspots
  transition_rates[which(recomb_scaled_hotspots > 0)]  = recomb_scaled_hotspots[which(recomb_scaled_hotspots > 0)]/nhaps_reference

  #If any NA's remain around edges, replace with the recomb rate rate besides it (bootstrap later)
  transition_rates           = na.locf(transition_rates)
  bp                         = genetic_map$position[(start_index):(end_index)]
  print(transition_rates)
  transition_rates           = as.matrix(transition_rates)
  rownames(transition_rates) = bp
  return(transition_rates)
}

transition_rates_genetic_map = function(transition_rates, #List of recombination rates by BP
                                        ref_panel,
                                        start_position,
                                        end_position,
                                        directory){       #Variants in our file
  bp               = as.numeric(colnames(ref_panel))
  print(bp)
  nsnps            = ncol(ref_panel)
  scaled_avg       = c()
  transition_rates = cbind(as.matrix(transition_rates),rownames(transition_rates))
  transition_rates = `class<-`(transition_rates, 'numeric')
  scaled_avg       = rep(NA,(nsnps))

  for (i in 1:(nsnps-3)) {
    leftward_recomb_index        = findInterval(bp[i],transition_rates[,2])
    rightward_recomb_index       = findInterval(bp[i],transition_rates[,2])+1
    distance_left_recomb_to_snp  = bp[i]-transition_rates[leftward_recomb_index,2]
    distance_right_recomb_to_snp = transition_rates[rightward_recomb_index,2] - bp[i]
    total_distance_breakpoints   = transition_rates[rightward_recomb_index,2]-transition_rates[leftward_recomb_index,2]

    if (transition_rates[leftward_recomb_index,2] == bp[i]) {
      scaled_avg[i] = unlist((transition_rates[leftward_recomb_index,1]))
    }
    if (transition_rates[rightward_recomb_index,2] != bp[i] & transition_rates[leftward_recomb_index,2] != bp[i] ){
      scaled_avg[i]    = unlist(transition_rates[leftward_recomb_index] + distance_left_recomb_to_snp/total_distance_breakpoints * (transition_rates[rightward_recomb_index]-transition_rates[leftward_recomb_index]))
    }
  }
  scaled_avg = na.locf(scaled_avg)
  write.table(scaled_avg,file = sprintf("/well/mcvean/mtutert/1000_Genomes/inference_files/%s/hmm_recomb_map",directory),
              quote     = FALSE,
              row.names = FALSE,
              col.names = FALSE)
  return(scaled_avg)
}
