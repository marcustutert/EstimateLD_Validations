LD_from_GSHMM = function(betas, #This is the file that will containtin all the GWAS SS data (previously uploaded to the cluster)
                                 #gwas_panel_haplotypes, #Contains the GWAS haplotypes (previously uploaded to the cluster)
                                 ref_panel_haplotypes, #Contains reference panel haplotypes (previously uploaded to the cluster)
                                 Fst,    #Set Fst
                                 alpha, #Set noise; remember lower alpha = more noise!
                                 nSamples,
                                 recomb_rate,
                                 weights_resolution,
                                 likelihood_toggle,
                                 se_observed,
                                 LD_Infer,
                                 genetic_map,
                                 chain_likelihood,
                                 nChains){
  library(matrixStats)
  #First get the constants that we need
  ref_panel_haplotypes = as.matrix(ref_panel_haplotypes)
  nsnps = ncol(ref_panel_haplotypes)
  nhaps = nrow(ref_panel_haplotypes)

  #Do the Gibbs Sampling process, store the results to an array
  ####Note that we may want to add some of these parameters

  #Loop through nChains and store the results in  a list [[Chain 1,...]]
  Chain_Results = vector("list", length = nChains)
  for (idx in 1:nChains) {
    #Store the results from the gibbs sampler
    results    = Gibbs_Sampling_HW_Array(recomb_rate         = recomb_rate,
                                         nSamples            = nSamples,
                                         weights_resolution  = weights_resolution,
                                         ref_allele_matrix   = ref_panel_haplotypes,
                                         Fst                 = Fst,
                                         alpha               = alpha,
                                         likelihood          = likelihood_toggle,
                                         se_observed         = se_observed,
                                         genetic_map         = genetic_map,
                                         chain_likelihood    = chain_likelihood)
    #Specific results we can store
    HW_Array       = results[[1]]
    recomb_events  = results[[2]]
    likelihood     = results[[3]]
    allele_freq    = results[[4]]
    #Normalize the gibbs array
    normalized_weights_array = array(data = rep(NA,nhaps*nsnps*nSamples), dim = c(nhaps,nsnps,nSamples))
    for (i in 1:nSamples) {
      if (nsnps > 1) {
        normalized_weights_array[,,i] = sweep(HW_Array[,,i], 2, colSums(HW_Array[,,i]), FUN="/")
      }
      else{
        weight_matrix_sum             = sum(HW_Array[,,i])
        normalized_weights_array[,,i] = HW_Array[,,i]/weight_matrix_sum
      }
    }

    #Get the markovian flows and store the LD
    if (LD_Infer == TRUE) {
      pseudo_LD_array  = array(data = rep(NA,nsnps*nsnps*nSamples),
                               dim = c(nsnps,nsnps,nSamples))

      for (i in 1:nSamples) {
        Qx_Array             = markovian_flow(HW_Matrix = normalized_weights_array[,,i],
                                              start     = 1,
                                              end       = ncol(ref_panel_haplotypes))

        pseudo_LD_array[,,i] = LD_flow_expectation(HW_Matrix         = normalized_weights_array[,,i],
                                                   ref_allele_matrix = ref_panel_haplotypes,
                                                   Qx_array          = Qx_Array)

        Chain_Results[[idx]][[1]] =  normalized_weights_array
        Chain_Results[[idx]][[2]] =  pseudo_LD_array
        Chain_Results[[idx]][[3]] =  likelihood
      }
    }
    Chain_Results[[idx]][[1]] = normalized_weights_array
    Chain_Results[[idx]][[2]] = recomb_events
    Chain_Results[[idx]][[3]] = likelihood
    Chain_Results[[idx]][[4]] = allele_freq
  }
  return(Chain_Results)
}
