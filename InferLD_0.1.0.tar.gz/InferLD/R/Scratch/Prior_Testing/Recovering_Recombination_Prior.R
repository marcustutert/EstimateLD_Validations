#Playground for testing Gibbs sampling of my HMM to predict GWAS haplotypes
library(stats)
library(plotly)
library(data.table)
###################################################################/
# Reading in the Data from 1000G
###################################################################/

haps = fread("~/Desktop/Oxford_Dphil/EstimateLD/tests/Data/Eur_Chr22_Filtered_First_40K_Variants.haps", header = TRUE)
haps<-haps[,-1:-5] #Take away all the naming conventions

#Create haplotype column names
hap_names <- sprintf("hap%s",seq(1:ncol(haps)))
colnames(haps) =  hap_names

#Transpose matrix to get it in same form as my other data
haps = t(haps)

###################################################################/
# Pick how big we want reference panel to be and the size of the region
###################################################################/
ref_panel_size = 100
haps           = haps[sample(nrow(haps), ref_panel_size), ]
nsnps          = 500
haps = haps[,1:nsnps]

###################################################################/
# Cleaning and Filtering the Data
###################################################################/
#Look at the initial pi_ref's make sure that they look ok...
pi_ref = colSums(haps)/nrow(haps)

#Restrict to only variants that are segregating in both populations and have an MAF > 0.1%.
seg_snps = which(pi_ref<0.95 & pi_ref>0.05)
haps = haps[,seg_snps]
pi_ref = colSums(haps)/nrow(haps)

###################################################################/
# Simulating the GWAS SE's from Drifted Pi_Pops
###################################################################/

#Get number of snps and haps from our ref_allele panel (haps)
nsnps = ncol(haps)
nhaps = nrow(haps)

#Now let's generate a list of drifted pi_pop's with NB model
Fst    = 0.05
# c      = 1/Fst-1
# alpha  = c*pi_ref
# beta   = c*(1-pi_ref)
# pi_pop = rbeta(nsnps, alpha, beta) Nichols Balding (infinite recomb.)

#Sample from a Gamma Distribution
sample_weights           = rgamma(n = nhaps, shape = 1/(nhaps*Fst), scale = 1)
normalize_sample_weights = sample_weights/(sum(sample_weights))
pi_pop                   = colSums(haps * normalize_sample_weights)

#Add some multiplicative Gamma noise on top of this
alpha = 1e2 #Larger alpha = smaller noise

#Generate the sigma^2 observed
observed_sigma_b = 1/(pi_pop*(1-pi_pop))*rgamma(nsnps,shape = alpha, scale = 1/alpha)

# ###################################################################/
# # Generate the Gamma Quantiled Weights and Weights Matrix
# ###################################################################/
#
# weights_resolution = 100
# #Generate the Gamma Quantiled Weight Space
# Gamma_Quantiled_Weights = Gamma_Weight_States(weights_resolution = weights_resolution, Fst = Fst, ref_allele_matrix = haps)
#
# #Uniformly draw weights from the quantiles for each SNP (draw number of weights equal to nhaps)
# weight_matrix = matrix( sample(Gamma_Quantiled_Weights, size = nhaps*nsnps, replace = TRUE, prob = NULL), ncol = nsnps, nrow = nhaps )
# #Create matrix of allele-frequencies to vectorize this all, use the code from Scratch for this purpose
# weight_initializion = initialize_weights(ref_allele_matrix = haps, fst = Fst, weight_matrix = weight_matrix, Gamma_Weights_States = Gamma_Quantiled_Weights, row_update = nhaps)

###################################################################/
#  Do We Converge on the Correct Allele Frequencies?
###################################################################/
recomb_rate = 0.01
nSamples    = 5e2
weights_resolution = 10

#Generate the Gamma Quantiled Weight Space
Gamma_Quantiled_Weights = Gamma_Weight_States(weights_resolution = weights_resolution, Fst = Fst, ref_allele_matrix = haps)

#Uniformly draw weights from the quantiles for each SNP (draw number of weights equal to nhaps)
weight_matrix = matrix( sample(Gamma_Quantiled_Weights, size = nhaps*nsnps, replace = TRUE, prob = NULL), ncol = nsnps, nrow = nhaps )
#Create matrix of allele-frequencies to vectorize this all, use the code from Scratch for this purpose
Gibbs_Allele_Freq = matrix(data = NA, nrow = nsnps, ncol = nSamples)
weights_matrix_sum       = colSums(weight_matrix)
weight_matrix_normalized = sweep(weight_matrix, 2, weights_matrix_sum, FUN = '/')

#Store a matrix to look at the number of recombination events per haplotype and per sample
recomb_events = matrix(data = NA, nrow = nhaps, ncol = nSamples)
Gibbs_Allele_Freq[,1]    = colSums(haps*weight_matrix_normalized)

#Run the Gibbs Sampling
for (j in 2:nSamples) {
  cat( sprintf("\r%d", j))
  for (idx in 1:nhaps){
    weight_initializion = weight_update(ref_allele_matrix = haps, fst = Fst, weight_matrix = weight_matrix, Gamma_Weights_States = Gamma_Quantiled_Weights, row_update = idx)

    #Use the function for prob given the implied sigma_b
    prob_normalized = prob_sigma_given_frequency(allele_frequency_matrix = weight_initializion, observed_sigma_b = observed_sigma_b, likelihood = FALSE, noise = alpha)

    #Get the forward pass through this matrix
    forward_pass_matrix = forward_pass_c(allele_frequency_matrix = prob_normalized, diag_transition = 1-recomb_rate)

    #Sample backwards through this forward matrix to get a single path through the posteriors
    path =  sample_HMM_path(forward_pass_matrix = forward_pass_matrix, diag_transition = 1-recomb_rate)
    weight_matrix[idx,] = Gamma_Quantiled_Weights[path]
    recomb_events[idx,j] = sum(diff(path)!=0) #The first column will be the initialization so NA (will trim later)
  }
  weights_matrix_sum       = colSums(weight_matrix)
  weight_matrix_normalized = sweep(weight_matrix, 2, weights_matrix_sum, FUN = '/')
  Gibbs_Allele_Freq[,j]    = colSums(haps*weight_matrix_normalized)
}

###################################################################/
#  Does the Recombination Events Follow A Binomial Distribution?
###################################################################/
#Trim the first column of NA's (initialization) away
recomb_events                      = recomb_events[,2:ncol(recomb_events)]
total_hap_recomb_events_per_sample = colSums(recomb_events)
density1 = density(total_hap_recomb_events_per_sample)
density2 = dbinom(x = 0:600, size = nhaps*nsnps, prob = recomb_rate)

#Plot the Densities of Empirical vs Observed
p <- plot_ly(x = ~density1$x, y = ~density1$y, type = 'scatter', mode = 'lines', name = 'Empirical Density', fill = 'tozeroy') %>%
  add_trace(x = 0:600, y = ~density2, name = 'Theoretical Density', fill = 'tozeroy') %>%
  layout(xaxis = list(title = 'Recombination Events'),
         yaxis = list(title = 'Density'))

show(p)
