library("microbenchmark")
weight_matrix_modified <- matrix(sample(1:100), nrow = 1000, ncol = 1000)
ref_allele_matrix <- matrix(sample(c(0L, 1L), 100, replace = TRUE), nrow = 1000, ncol = 5)
f1 <- function() {
  weight_matrix_sum <-(colSums(weight_matrix_modified))
  weight_matrix_normalized <- weight_matrix_modified %*% diag(1/weight_matrix_sum)
  colSums(weight_matrix_normalized * ref_allele_matrix[,i])
}
f2 <- function() {
  colSums(weight_matrix_modified * ref_allele_matrix[, i]) / colSums(weight_matrix_modified)
}
microbenchmark(f1(), f2(), times = 3L)
## try something bigger
library("Rcpp")
Rcpp::cppFunction("
NumericVector new_interior(
    NumericMatrix weight_matrix_modified,
    NumericMatrix ref_allele_matrix,
    int i
) {
    int nc = weight_matrix_modified.ncol();
    int nr = weight_matrix_modified.ncol();
    NumericVector val(nc);
    NumericVector ref_vector = ref_allele_matrix(_, i);
    double v, d;
    for(int i_col = 0; i_col < nc; i_col++) {
       v = 0;
       d = 0;
       for(int i_row = 0; i_row < nr; i_row++) {
           v += weight_matrix_modified(i_row, i_col) * ref_vector(i_row);
           d += weight_matrix_modified(i_row, i_col);
       }
       val(i_col) = v / d;
    }
    return(val);
}")
result <- new_interior(weight_matrix_modified, ref_allele_matrix, i)
f3 <- function() {
  new_interior(weight_matrix_modified, ref_allele_matrix, i)
}
microbenchmark(f1(), f2(), f3(), times = 3L)
