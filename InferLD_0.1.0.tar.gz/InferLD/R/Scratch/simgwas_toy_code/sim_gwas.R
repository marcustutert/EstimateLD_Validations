#Functions to run SIMGWAS analysis

#This function will take in haplotypes (from msprime usually) and output list of GWAS SS
#Outputs betas and se betas (for input into inference method, saves it as a table(?))
gwas_sim = function(haplotypes,   #These are the GWAS Haplotypes from msprime (matrix)
                    ncausal_snps      = 1, #Number of causal SNPs (numberic),
                    causal_snps_index = c(1), #index of SNP(s) which are causal
                    odds_ratio        = c(1), #Odds ratios for causal SNPS (vector)
                    ncases            = nrow(haplotypes)/2, #Ncases in GWAS, default will be 50/50 split
                    ncontrols         = nrow(haplotypes)/2, #Ncontrols in GWAS
                    null              = FALSE,
                    LD_Matrix) #If null zscores is true, then use seperate function)
{
  #Load in packages
  library(combinat)
  library(simGWAS)

  #First define constants re: data at hand
  nsnps = ncol(haplotypes)
  nhaps = nrow(haplotypes)

  #Create LD from list of haplotypes
  #GWAS_LD = LD_Matrix(haplotypes = haplotypes)
  #Make positive definite
  GWAS_LD <- as.matrix(LD_Matrix)

  #We need to create the dataframe with SNP frequency (assume data has already been QC'd)
  snps <- colnames(haplotypes) <- paste0("snp",1:nsnps) #List of SNPs (change rsid later)
  freq = as.data.frame(haplotypes+1) #Create column for frequency
  freq$Probability <- 1/nrow(freq)   #Frequency of each haplotype (uniform for now)
  FP   = make_GenoProbList(snps=snps,W=c(paste0("snp",causal_snps_index)),freq=freq)
  #Now we will take the haplotypes from the GWAS and build the SS with the sim gwas package
  #First we want the estimated z statistics

  if (null == TRUE) { #Under the null model
      expected_z_score = simulated_z_null(snps = snps, freq = freq, nrep = 1e3) #Only one replicate
  }
  else{               #Under causal model
      expected_z_score = expected_z_score(N0   = ncontrols, # number of controls
                         N1           = ncases, # number of cases
                         snps         = snps, # column names in freq of SNPs for which Z scores should be generated
                         W            = paste0("snp",causal_snps_index), # causal variants, subset of snps
                         gamma.W      = log(odds_ratio), # odds ratios
                         freq         = freq, # reference haplotypes
                         GenoProbList = FP) # FP above
  }

  #Next we need to take the simulated z scores and use multivariate normal draw
  sim_z_scores <- rmvnorm(n = 1e3, mean = colMeans(expected_z_score), sigma = GWAS_LD)

  #Now we need to calculate the variance of the beta (beta SE^2)
  sim_var_beta <- simulated_vbeta(N0   = ncontrols, # number of controls
                          N1           = ncases, # number of cases
                          snps         = snps, # column names in freq of SNPs for which Z scores should be generated
                          W            = paste0("snp",causal_snps_index), # causal variants, subset of snps
                          gamma.W      = log(odds_ratio), # odds ratios
                          freq         = freq, # reference haplotypes
                          GenoProbList = FP,
                          nrep         = 1e3)

  sim_z_means   = colMeans(sim_z_scores)
  sim_var_means = colMeans(sim_var_beta)
  #Then we just back out the beta's as we normally would
  sim_beta      =  sim_z_means* sqrt(sim_var_means)

  #Output the betas and SE betas as a table
  gwas_ss       = cbind((sim_beta),(sim_var_means))
  return(gwas_ss)
}
# ref_prob_fmp = rep(NA,438)
# gwas_prob_fmp = rep(NA,438)
# for (j in 1:438) {
#   print(j)
#   #Do this 1000x then average the zscores
#   zsim_beta  = matrix(data = NA, nrow = 438, ncol = 50)
#   zsim_se    = matrix(data = NA, nrow = 438, ncol = 50)
#   causal_snp = seq(1:438)[i]
#   for (i in 1:50) {
#     zsim_beta[,i] =gwas_sim(haplotypes = gwas_true, ncausal_snps = 1, causal_snps_index = c(i),odds_ratio = c(1.5),null = FALSE, LD_Matrix = LD_Matrix(gwas_true))[,1]
#     zsim_se[,i]   =gwas_sim(haplotypes = gwas_true, ncausal_snps = 1, causal_snps_index = c(i),odds_ratio = c(1.5),null = FALSE, LD_Matrix = LD_Matrix(gwas_true))[,2]
#   }
#   beta_mean    = rowMeans(zsim_beta)
#   beta_se_mean = rowMeans(zsim_se)
#   gwas_ss = cbind(beta_mean,beta_se_mean)
#
#   finemap_benner(gwas_ss = gwas_ss,study_name = "test",gwas_haps = ref_panel_haplotypes,LD_Panel=LD_Matrix(gwas_true))
#   snp_prob = read.table("test/test.snp")
#   snp_prob = snp_prob[,c(2,11)] #Filter out probabiltiies and SNP index
#   gwas_prob_fmp[j] = as.vector(snp_prob[which(sprintf("snp%s",causal_snp) == snp_prob[,1]),2])
#
#
#   finemap_benner(gwas_ss = gwas_ss,study_name = "test",gwas_haps = ref_panel_haplotypes,LD_Panel=LD_Matrix(ref_panel_haplotypes))
#   snp_prob = read.table("test/test.snp")
#   snp_prob = snp_prob[,c(2,11)] #Filter out probabiltiies and SNP index
#   ref_prob_fmp[j] = as.vector(snp_prob[which(sprintf("snp%s",causal_snp) == snp_prob[,1]),2])
# }
