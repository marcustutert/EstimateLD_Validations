#Functions to perform fine-mapping and displaying posterior prob of potential causal variants
#Will be using benners FINEMAP software

finemap_benner = function(gwas_ss,
                          LD_Panel,
                          study_name,#String, will be prefix of all the files
                          gwas_haps #Potentially unknown (won't be used for finemapping, rather for parameter defs)
                          )
{
  #Define constants
  nsnps = nrow(gwas_ss)

  #First we need to create the files necessary to run the fine-mapping
  #We will store them locally in /Users/marcustutert/Desktop/Oxford_Dphil/EstimateLD/GWAS_Sims_Finemapping
  #There are three files we need a master file, and LD file & a Z file that all have seperate directories
  dir.create(sprintf("/Users/marcustutert/Desktop/Oxford_Dphil/EstimateLD/GWAS_Sims_Finemapping/%s",study_name))

  ############ Master File ###############

  #The master file is a semicolon-separated text file and contains no space
  master_file_col_names = paste("z","ld","snp","config","cred","log","n_samples",sep = ";")
  #Now each line will be a separate dataset (later on the line we can combine the files?)
  #We'll sprintf each seperate for convience then paste em al ltogether
  z_file        = sprintf("%s/%s.z",study_name,study_name)
  ld_file       = sprintf("%s/%s.ld",study_name,study_name)
  snp_file      = sprintf("%s/%s.snp",study_name,study_name)
  config_file   = sprintf("%s/%s.config",study_name,study_name)
  cred_set_file = sprintf("%s/%s.cred",study_name,study_name)
  log_file      = sprintf("%s/%s.log",study_name,study_name)
  nsample_study = nrow(gwas_haps) #This can be hard-coded I guess

  #Paste em together
  master_file_data_names = paste(z_file,ld_file,snp_file,config_file,cred_set_file,log_file,nsample_study,sep = ";")
  #Create dataframe from it
  master_file           = as.data.frame(master_file_data_names)
  colnames(master_file) = master_file_col_names

  #Write the table to directory
  write.table(x = master_file,
              file = sprintf("/Users/marcustutert/Desktop/Oxford_Dphil/EstimateLD/GWAS_Sims_Finemapping/finemap_v1.4_MacOSX/%s/master", study_name),
              quote = FALSE,
              row.names = FALSE,
              col.names = TRUE)

  ############ LD File ###############
  write.table(x = LD_Panel,
              sprintf("/Users/marcustutert/Desktop/Oxford_Dphil/EstimateLD/GWAS_Sims_Finemapping/finemap_v1.4_MacOSX/%s/%s.ld",study_name,study_name),
              quote = FALSE,
              row.names = FALSE,
              col.names = FALSE)

  ########## Z File ##########
  #Get col names for the z file
  z_file_col_names = paste("rsid","chromosome","position","allele1","allele2","maf","beta","se",sep = " ")
  #Get the data for each row (assuming no genomic position, this is from msprime )
  rsid       = paste("snp",seq(1:nsnps), sep = "")
  chromosome = paste("chr1",seq(1:nsnps), sep = "")
  position   = seq(1:nsnps)
  allele1    = rep("A",nsnps)
  allele2    = rep("T",nsnps)
  maf        = ifelse(colMeans(gwas_haps)>0.5,1-colMeans(gwas_haps),colMeans(gwas_haps))
  beta       = gwas_ss[,1]
  se         = gwas_ss[,2]

    z_file_data_names = paste(rsid,chromosome,position,allele1,allele2,maf,beta,se,sep = " ")

  z_file           = as.data.frame(z_file_data_names)
  colnames(z_file) = z_file_col_names

  #Write the table to directory
  write.table(x = z_file,
              file = sprintf("/Users/marcustutert/Desktop/Oxford_Dphil/EstimateLD/GWAS_Sims_Finemapping/finemap_v1.4_MacOSX/%s/%s.z", study_name,study_name),
              quote = FALSE,
              row.names = FALSE,
              col.names = TRUE)

  #### Run FINEMAP ####
  setwd("/Users/marcustutert/Desktop/Oxford_Dphil/EstimateLD/GWAS_Sims_Finemapping/finemap_v1.4_MacOSX")
  #Run it from command line
  system(sprintf("~/Desktop/Oxford_Dphil/EstimateLD/GWAS_Sims_Finemapping/finemap_v1.4_MacOSX/finemap_v1.4_MacOSX --sss --in-files /Users/marcustutert/Desktop/Oxford_Dphil/EstimateLD/GWAS_Sims_Finemapping/finemap_v1.4_MacOSX/%s/master  --dataset 1 --n-causal-snps 2", study_name))
}
