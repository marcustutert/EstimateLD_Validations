z_scores_truth = gwas_ss[,2]/gwas_ss[,3]
#Toy Code to show Impact of Reference Panels
untyped = sort(sample(seq(1:438),200))
typed = sort(seq(1:438)[-untyped])
t_ref = impute(ref_panel_haplotypes,
           sites.typed = typed,
           betas       = gwas_ss[typed,2],
           sd.betas    = gwas_ss[typed,3],
           LD          = LD_Matrix(ref_panel_haplotypes))
#Now fill in gwas_ss table
z_scores_ref          = gwas_ss[,2]/gwas_ss[,3]
z_scores_ref[untyped] = t_ref

t_gwas = impute(ref_panel_haplotypes,
                sites.typed = typed,
                betas       = gwas_ss[typed,2],
                sd.betas    = gwas_ss[typed,3],
                LD          = LD_Matrix(gwas_true))
z_scores_gwas          = gwas_ss[,2]/gwas_ss[,3]
z_scores_gwas[untyped] = t_gwas

t_recomb = impute(ref_panel_haplotypes,
                sites.typed = typed,
                betas       = gwas_ss[typed,2],
                sd.betas    = gwas_ss[typed,3],
                LD          = recomb)
z_scores_recomb          = gwas_ss[,2]/gwas_ss[,3]
z_scores_recomb[untyped] = t_recomb

t_nonrecomb = impute(ref_panel_haplotypes,
                  sites.typed = typed,
                  betas       = gwas_ss[typed,2],
                  sd.betas    = gwas_ss[typed,3],
                  LD          = non_recomb)
z_scores_nonrecomb          = gwas_ss[,2]/gwas_ss[,3]
z_scores_nonrecomb[untyped] = t_nonrecomb

#Plot this as a scatter plot
fig <- plot_ly(data = iris, x = ~seq(1:438))
fig <- fig %>% add_trace(y = ~z_scores_gwas, name = 'GWAS',mode = 'markers')
fig <- fig %>% add_trace(y = ~z_scores_ref, name = 'Ref', mode = 'markers')
fig <- fig %>% add_trace(y = ~z_scores_truth, name = 'Truth', mode = 'markers')
fig <- fig %>% add_trace(y = ~z_scores_nonrecomb, name = 'No Recomb', mode = 'markers')
fig <- fig %>% add_trace(y = ~z_scores_recomb, name = 'Recomb', mode = 'markers')

fig = plot_ly(data = iris, x = ~z_scores_truth[-typed])
fig = fig %>% add_trace(y = ~z_scores_gwas[-typed], name = 'GWAS',mode = 'markers')
fig = fig %>% add_trace(y = ~z_scores_ref[-typed], name = 'Ref',mode = 'markers')
fig = fig %>% add_trace(y = ~z_scores_nonrecomb[-typed], name = 'No Recomb',mode = 'markers')
fig = fig %>% add_trace(y = ~z_scores_recomb[-typed], name = 'Recomb',mode = 'markers')
