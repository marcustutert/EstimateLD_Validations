#Code to run toy example inference method

#Perform analysis of hap reconstruction from GWAS SS
library("RColorBrewer")
library("mvtnorm");

#setwd("C:/Users/Gil/OneDrive - Nexus365/NDPH_OwnCloud/Marcus");
#Function to calculate likelihood given reference haplotyes across all possible SNPs
calc.llk.full<-function(ref.hap, #Reference haplotypes
                        wt.mtx,  #Gamma Weights on haplotypes
                        o.var,   #GWAS SE^2
                        shp.noise, #Noise alpha parameter
                        SHAPE.HET=FALSE, #To adjust LL for MAF
                        show.plot=TRUE) {

	vals<-wt.mtx * ref.hap; #Multiply weights by reference haplotypes (Matrix?)
	af.gwas<-colSums(vals)/colSums(wt.mtx) #Transform into MAF
	het.gwas<-2*af.gwas*(1-af.gwas) #Implied het of weights (turned off for now)

	if (SHAPE.HET == TRUE) { #MAF Dependent likelihood
		shp.site<-shp.noise*het.gwas
	} else {
		shp.site<-shp.noise
	}

	rr<-(o.var*het.gwas) #Ratio of SE^2
	#browser()
	llk.site<-dgamma(rr, shp.site, shp.site, log=T) #Calculate likelihood (log scale)

	if (show.plot) { #Default True
	  #Plot the weighted het against gwas implied het(?)
		plot(het.gwas, 1/o.var, pch=19, col="darkblue", xlab="Weighted Het", ylab="GWAS implied Het")
		abline(0,1,lty="dotted")
	}

	#Sum of log liklelihood across sites
	return(sum(llk.site))
}

#Calculate likelihood at a particular variant
calc.lk.site<-function(fq.vals, #Frequency
                       o.var, #SE
                       shp.site, #Noise parameter
                       debug=FALSE, #Return 1's if true
                       SHAPE.HET=FALSE) {

	if (debug) return(rep(1, length(fq.vals)))

	het<-2*fq.vals*(1-fq.vals) #Het vaules(?)
	rr<-o.var*het; #Ratio of SE's implied/observed

	if (SHAPE.HET) { #MAF Dependent Version
		lk<-dgamma(rr, shp.site*het, shp.site*het) #Likelihood
	} else {
		lk<-dgamma(rr, shp.site, shp.site) #LL
	}

	return(lk) #Return likelilood (real space)
}


#############
#Simulate some data
#############

DEBUG<-TRUE
DEBUG<-FALSE
INCLUDE.BETA<-TRUE
SHAPE.HET<-FALSE

#File names
ref_hap.fn<-"R/Scratch/Beta_LL_Toy_Code/ref1.txt" #Reference haplotypes file (see generateGWAS_SS.R)
gwas_ss.fn<-"R/Scratch/Beta_LL_Toy_Code/sim1.txt" #GWAS SS ("")

p.rec       = 1e-100#Rec rate between adjacent sites
noise.shape = 100		#Shape parameter for Gamma noise distribution (multiplied by implied Het(?))
n.gwas      = 1e4	  #GWAS pop size, to be estimated previously (median of SE)
phi.gwas    = 0.5		#Case proportion in GWAS (calculated separately)
fst         = 0.2		#Fst parameter
nq          = 100		#Number of weights for prior (states)
n.it        = 1e3   #No. of iteractions in MCMC
samp.rate   = 10		#Rate at which samples are taken (?)

ref.hap = as.matrix(read.table(ref_hap.fn, #Read in ref haplotypes
                              as.is=T,
                              head=F,
                              colClasses="numeric"))

gwas.ss = read.table(gwas_ss.fn, as.is=T, head=T, colClasses="numeric") #Read in GWAS SS
fq.ref  = colMeans(ref.hap) #Reference haplotype freqs
z.gwas  = gwas.ss[,2]/gwas.ss[,3] #Get GWAS Z scores

n.snp = ncol(ref.hap) #Number of SNPs in reference
n.ref = nrow(ref.hap) #Number of reference haplotypes

#First, rescale o.var to remove non-AF related terms(?)
fac   = 1/(n.gwas*phi.gwas*(1-phi.gwas)) #Rescaling factor (pop size & case control prop. %)
o.var = gwas.ss[,3]^2/fac #Convert sigma to sigma^2 and normalize

het.ref = 2*fq.ref*(1-fq.ref)
plot(1/het.ref, o.var, pch=19, col="darkblue", xlab="Expected std. Var(beta)", ylab="Observed std. Var(beta)");
abline(0,1,lty="dotted") #Plot expected vs observed sigma's (should be roughly linear @ low Fst)


############################################
#Initialize Weights (ZERO RECOMBINATION CASE)
#############################################

#Set up weights
shp.gamma.wts = 1/n.ref * (1-fst)/fst #Gamma Quantiled weight shapes
wt.prior      = qgamma((1:nq)/(1+nq), shp.gamma.wts, shp.gamma.wts) #Gamma prior
wt.prior      = wt.prior*1/mean(wt.prior) #Fix so that weights are drawn with mean = 1 (alpha = beta on gamma)

#Initialise weight matrix
alpha.init = 1
wt.mtx = array(rgamma(n.ref*l.ref, #Draw full grid of points!
                     alpha.init,
                     alpha.init), #Initailize with alpha = 1(?)
              c(n.ref, l.ref)) #Create array dimensions (nhaps x nsnps)

#Calculate weighted LD matrix and calculate LLK of Z values
cor.wt = cov.wt(ref.hap, wt.mtx[,1], method="ML", cor=TRUE); #Weighted covariance matrix

#Output from inference storage
f.mat         = array(0, c(nq, l.ref)) #Foward Matrix
n.samp        = floor(n.it/samp.rate)+1 #NSamples (full sweep?)
llk.samp      = rep(0, n.samp) #Store llk across full sweeps
llk.z.samp    = rep(0, n.samp) #Store the inferred llk z scores across full sweeps
llk.samp[1]   = calc.llk.full(ref.hap, wt.mtx, o.var, noise.shape, SHAPE.HET=SHAPE.HET) #Full LLK at first sample(?)
llk.z.samp[1] = dmvnorm(z.gwas, rep(0, l.ref), cor.wt$cor, log=T) #
af.samp       = array(0, c(l.ref, n.samp)) #Store the AF across each sample
af.samp[,1]   = colSums(wt.mtx*ref.hap)/colSums(wt.mtx); #First AF initialized(?)

##### Two Locus Case ###
d11.samp    = rep(0, n.samp) #LD measure (D ie: pAB-pA*pB)
d11.samp[1] = cor.wt$cov[1,2] #First D measure inferred (initalized?)

wmx         = rep(0, l.ref) #Max weight storage
state.hap   = rep(0, l.ref) #Haplotype states?
samp.ct     = 1 #Sampling counter
pal<-brewer.pal(l.ref, "Set1")

#########
#Inference
#########

sum.wts.site = colSums(wt.mtx) #Weights summation across sites?
sum.wts.1    = colSums(wt.mtx*ref.hap) #First weights inference?

cat("\n\nRunning MCMC\n\n") #Run MCMC inference
llk.0 = -llk.z.samp[1] #Store the initialize LLK

for (it in 1:n.it) { #Loop over all iterations... (Full Gibbs Update)

	wt.mtx.old = wt.mtx #Update weight matrix given older one

	#Choose an update order
	oo<-sample(n.ref) #Which haplotypes do we update first (random order for now)

	for (hap in 1:n.ref) { #Loop over the haplotypes

		wi            = oo[hap] #Indicator for updating which haplotype in reference panel
		wts.minus.hap = sum.wts.site - wt.mtx[wi,] #Find sum of weights minus weight at row we udpate
		af.minus.hap  = sum.wts.1 - wt.mtx[wi,]*ref.hap[wi,]; #Allele frequency at that haplotype given new state(?)

		#Initialise forward matrix
		v.tot     = wts.minus.hap[1]+wt.prior #Log Scale
		v.1       = af.minus.hap[1]+wt.prior*ref.hap[wi,1];
		f.1       = v.1/v.tot; #Normalize
		#browser()
		f.mat[,1] = calc.lk.site(f.1, o.var[1], noise.shape, debug=DEBUG, SHAPE.HET=SHAPE.HET)
		f.mat[,1] = f.mat[,1]/max(f.mat[,1]);
		wmx[1]<-which.max(f.mat[,1]);

		#Iterate through sites (loop through forward matrix)
		for (s in 2:l.ref) {
			v.tot     = wts.minus.hap[s]+wt.prior;
			v.1       = af.minus.hap[s]+wt.prior*ref.hap[wi,s];
			f.1       = v.1/v.tot;
			lk.state  = calc.lk.site(f.1, o.var[s], noise.shape, debug=DEBUG, SHAPE.HET=SHAPE.HET);
			f.mat[,s] = (f.mat[,s-1]*(1-p.rec)+p.rec)*lk.state;
			f.mat[,s] = f.mat[,s]/max(f.mat[,s]);
		} #Return forward matrix

		#Sample path through states
		state.hap[l.ref] = sample(nq, 1, p=f.mat[,l.ref]);
    #state.hap[l.ref]<-which.max(f.mat[,l.ref]); #'Viterbi' like maximization
		for (s in (l.ref-1):1) {
			state.hap[s] = state.hap[s+1];	#TO UPDATE IF REC (?)
		}
		#Update all parameters
		wts.hap      = wt.prior[state.hap]
		wt.mtx[wi,]  = wts.hap;
		sum.wts.site = wts.minus.hap+wts.hap;
		sum.wts.1    = af.minus.hap+wts.hap*ref.hap[wi,]
	}

	#After sweeping through haps, do rejection step using LD matrix ONLY
	if (INCLUDE.BETA) { #Beta form for the likelihood
		cor.wt = cov.wt(ref.hap, wt.mtx[,1], method="ML", cor=TRUE) #Get LD matrix from weighted reference haplotypes
		llk.1  = dmvnorm(z.gwas, rep(0, l.ref), cor.wt$cor, log=T)  #Draw from MVN distr prob.
		#browser()

		if (runif(1)<exp(llk.1-llk.0)) {	#MH rejection step
			llk.0 = llk.1 #Update LL
		} else { #Accept the update
			wt.mtx       = wt.mtx.old;
			sum.wts.site = colSums(wt.mtx);
			sum.wts.1    = colSums(wt.mtx*ref.hap);
		}
	}

	#Record sample, and update counters etc.
	if ((it %% samp.rate) == 0) {
		cat("\rSampling at iteration\t", it) #Which sample are we on
		samp.ct             = samp.ct+1 #Update sample counter
		llk.samp[samp.ct]   = calc.llk.full(ref.hap, wt.mtx, o.var, noise.shape, show.plot=FALSE, SHAPE.HET=SHAPE.HET) #Keep track of LLK
		af.samp[,samp.ct]   = colSums(wt.mtx*ref.hap)/colSums(wt.mtx) #AF
		cor.wt              = cov.wt(ref.hap, wt.mtx[,1], method="ML", cor=TRUE) #Correlation update
		llk.z.samp[samp.ct] = dmvnorm(z.gwas, rep(0, l.ref), cor.wt$cor, log=T)  #LLK z score
		d11.samp[samp.ct]   = cor.wt$cov[1,2] #LD D statistic
	}

}

cat("\n\nDone!!\n\n") #Finish MCMC

#Plot traces
par(mfrow=c(1,3));
plot(llk.samp, xlab="Sample", ylab="LLK", pch=19, col="darkblue", bty="n", main="LLK", cex=0.5);
plot(af.samp[1,], ylim=c(0,1), xlab="Sample", ylab="Frequency", pch=19, col=pal[1],
	bty="n", main="Allele Frequency", cex=0.5);
for (j in 2:l.ref) points(af.samp[j,], pch=19, col=pal[j], cex=0.5);
r.samp<-(d11.samp)/sqrt(af.samp[1,]*(1-af.samp[1,])*af.samp[2,]*(1-af.samp[2,]));
lines(abs(r.samp), col=hsv(0,0,0,alpha=0.5));
calc.llk.full(ref.hap, wt.mtx, o.var, noise.shape, show=T)


