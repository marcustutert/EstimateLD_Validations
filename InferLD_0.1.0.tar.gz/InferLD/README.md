# LD_Infer
Inferring distributions of linkage disequilibrium from GWAS summary statistics


## R code for testing, building, etc
```

pkg <- "/Users/marcustutert/Desktop/Oxford_Dphil/InferLD"
devtools::build(pkg = pkg)
devtools::document(pkg)
devtools::load_all(pkg, quiet = FALSE)
package_tarball <- devtools::build(pkg = pkg, manual = TRUE)
install.packages(package_tarball, repos = NULL, type ="source")

devtools::test("/Users/marcustutert/Desktop/Oxford_Dphil/InferLD", reporter = "summary")

```


## R code for profiling

```
## from InferLD repo home
./scripts/profile.R

###To source and see likelihoods run profvis_profile.R file
```

