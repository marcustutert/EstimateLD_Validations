#Code for Robbie to profile the code
test_that("Reference and GWAS Identical; Learn LD", {
  set.seed(245)
  #Set number of haplotypes and variants to a small number so we can do testing and debugging
  nhaps = 100  #Haplotypes in the reference panel
  nsnps = 30 #Variants in the reference panel

  path = dirname(getwd()) #Set path relative to testing folder
  #Load in 1000G data from ./Test/Data
  ref_hap_panel     = as.matrix(read.table(sprintf('%s/Data/ref_panel_filtered',path),
                                                    header = TRUE))

  #Subset to nhaps and nsnps size to make testing easier
  ref_hap_panel     = ref_hap_panel[ 1:nhaps, 1:nsnps ]

  #Filter out SNPs that are above/below a threshhold

  #Get AF of the variants in the reference pnale
  ref_variants_af   = colMeans(ref_hap_panel)
  #Assume that allele frequencies are the same in the reference panel and the GWAS panel
  gwas_variants_af  = ref_variants_af

  #Filter out SNPs that are above/below a threshhold (0-100% exclusive)
  filter_snp_index  = which(colMeans(ref_hap_panel) > 0.99)

  gwas_variants_af  = gwas_variants_af[-filter_snp_index]
  ref_hap_panel     = ref_hap_panel[,-filter_snp_index]

  #Transform AF's to SE
  observed_gwas_se  = 1/(gwas_variants_af*(1-gwas_variants_af))
  results           = LD_from_GSHMM(ref_panel_haplotypes = ref_hap_panel,
                                    Fst                  = 1e-4,
                                    betas                = FALSE,
                                    alpha                = 1e3,
                                    nSamples             = 50,
                                    recomb_rate          = 1e-10,
                                    weights_resolution   = 10,
                                    likelihood           = TRUE,
                                    se_observed          = observed_gwas_se,
                                    LD_Infer             = TRUE,
                                    genetic_map          = FALSE,
                                    chain_likelihood     = TRUE)
  LD = results[[2]]
  LD[!is.finite(LD)] <- 0
  LD_mean = apply(LD, c(1,2), mean)
  True_LD = LD_Matrix(ref_hap_panel)
  True_LD[!is.finite(True_LD)] <- 0
  expect_equal(c(True_LD), c(LD_mean), tolerance = 0.01)
})
