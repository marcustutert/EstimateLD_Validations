Sys.setenv("R_TESTS" = "")
library(testthat)
library(EstimateLD)
test_check("LDInfer")
